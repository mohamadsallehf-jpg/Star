#!/bin/bash

# ═══════════════════════════════════════════════════════════════
# 🎮 StarWars Bot - Stop Script
# اسکریپت توقف ربات
# ═══════════════════════════════════════════════════════════════

echo "🛑 توقف ربات جنگ ستارگان..."

# Check if PID file exists
if [ ! -f "bot.pid" ]; then
    echo "⚠️  فایل PID یافت نشد! ربات در حال اجرا نیست."
    exit 1
fi

# Read PID
PID=$(cat bot.pid)

# Check if process is running
if ! ps -p $PID > /dev/null 2>&1; then
    echo "⚠️  پروسه با PID $PID یافت نشد!"
    rm bot.pid
    exit 1
fi

# Kill process
echo "⏳ در حال توقف پروسه $PID..."
kill $PID

# Wait for process to stop
for i in {1..10}; do
    if ! ps -p $PID > /dev/null 2>&1; then
        echo "✅ ربات با موفقیت متوقف شد!"
        rm bot.pid
        exit 0
    fi
    sleep 1
done

# Force kill if still running
echo "⚠️  پروسه متوقف نشد، در حال force kill..."
kill -9 $PID
rm bot.pid
echo "✅ ربات به زور متوقف شد!"
