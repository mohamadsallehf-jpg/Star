"""
🎮 StarWars Bot - User Model
مدل کاربر با تمام ویژگی‌های بازی
"""

from datetime import datetime
from typing import Optional, Dict, Any, List
from sqlalchemy import (
    BigInteger, String, Integer, Float, Boolean,
    DateTime, JSON, Text, Index
)
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base


class User(Base):
    """مدل کاربر با تمام اطلاعات بازی"""
    
    __tablename__ = "users"
    
    # ═══════════════════════════════════════════════════════════════
    # Basic Info
    # ═══════════════════════════════════════════════════════════════
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    username: Mapped[Optional[str]] = mapped_column(String(255), nullable=True, index=True)
    first_name: Mapped[str] = mapped_column(String(255))
    last_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    
    # ═══════════════════════════════════════════════════════════════
    # Status & Permissions
    # ═══════════════════════════════════════════════════════════════
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False)
    is_vip: Mapped[bool] = mapped_column(Boolean, default=False)
    vip_level: Mapped[int] = mapped_column(Integer, default=0)
    vip_expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # ═══════════════════════════════════════════════════════════════
    # Economy
    # ═══════════════════════════════════════════════════════════════
    toman: Mapped[int] = mapped_column(BigInteger, default=5000)
    bank: Mapped[int] = mapped_column(BigInteger, default=0)
    ruby: Mapped[int] = mapped_column(Integer, default=50)
    trophy: Mapped[int] = mapped_column(Integer, default=100)
    
    # ═══════════════════════════════════════════════════════════════
    # Level & Experience
    # ═══════════════════════════════════════════════════════════════
    level: Mapped[int] = mapped_column(Integer, default=1)
    xp: Mapped[int] = mapped_column(Integer, default=0)
    total_xp: Mapped[int] = mapped_column(BigInteger, default=0)
    
    # ═══════════════════════════════════════════════════════════════
    # Base Stats
    # ═══════════════════════════════════════════════════════════════
    health: Mapped[int] = mapped_column(Integer, default=100)
    max_health: Mapped[int] = mapped_column(Integer, default=100)
    shield: Mapped[int] = mapped_column(Integer, default=0)
    max_shield: Mapped[int] = mapped_column(Integer, default=100)
    
    # ═══════════════════════════════════════════════════════════════
    # Combat Stats
    # ═══════════════════════════════════════════════════════════════
    total_attacks: Mapped[int] = mapped_column(Integer, default=0)
    successful_attacks: Mapped[int] = mapped_column(Integer, default=0)
    failed_attacks: Mapped[int] = mapped_column(Integer, default=0)
    total_damage_dealt: Mapped[int] = mapped_column(BigInteger, default=0)
    total_damage_received: Mapped[int] = mapped_column(BigInteger, default=0)
    
    # ═══════════════════════════════════════════════════════════════
    # Arsenal (JSON stored as text for SQLite compatibility)
    # ═══════════════════════════════════════════════════════════════
    missiles: Mapped[Dict[str, int]] = mapped_column(JSON, default=dict)
    tanks: Mapped[Dict[str, Dict[str, Any]]] = mapped_column(JSON, default=dict)
    fighters: Mapped[Dict[str, Dict[str, Any]]] = mapped_column(JSON, default=dict)
    warships: Mapped[Dict[str, Dict[str, Any]]] = mapped_column(JSON, default=dict)
    drones: Mapped[Dict[str, Dict[str, Any]]] = mapped_column(JSON, default=dict)
    
    # ═══════════════════════════════════════════════════════════════
    # Defense Systems
    # ═══════════════════════════════════════════════════════════════
    defenses: Mapped[Dict[str, int]] = mapped_column(JSON, default=dict)
    cyber_defenses: Mapped[Dict[str, int]] = mapped_column(JSON, default=dict)
    cyber_attacks: Mapped[Dict[str, int]] = mapped_column(JSON, default=dict)
    
    # ═══════════════════════════════════════════════════════════════
    # Cooldowns (store as timestamp)
    # ═══════════════════════════════════════════════════════════════
    last_work: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_coin: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_daily: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_mine: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_attack: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # ═══════════════════════════════════════════════════════════════
    # Achievements & Missions
    # ═══════════════════════════════════════════════════════════════
    achievements: Mapped[List[str]] = mapped_column(JSON, default=list)
    daily_missions: Mapped[Dict[str, int]] = mapped_column(JSON, default=dict)
    mission_last_reset: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # ═══════════════════════════════════════════════════════════════
    # Lucky Box
    # ═══════════════════════════════════════════════════════════════
    lucky_boxes: Mapped[List[str]] = mapped_column(JSON, default=list)
    
    # ═══════════════════════════════════════════════════════════════
    # Settings & Preferences
    # ═══════════════════════════════════════════════════════════════
    language: Mapped[str] = mapped_column(String(10), default="fa")
    notifications_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # ═══════════════════════════════════════════════════════════════
    # Timestamps
    # ═══════════════════════════════════════════════════════════════
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_seen: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    
    # ═══════════════════════════════════════════════════════════════
    # Indexes for better query performance
    # ═══════════════════════════════════════════════════════════════
    __table_args__ = (
        Index('idx_user_level', 'level'),
        Index('idx_user_toman', 'toman'),
        Index('idx_user_trophy', 'trophy'),
        Index('idx_user_created_at', 'created_at'),
    )
    
    # ═══════════════════════════════════════════════════════════════
    # Properties
    # ═══════════════════════════════════════════════════════════════
    
    @property
    def full_name(self) -> str:
        """Get user's full name"""
        if self.last_name:
            return f"{self.first_name} {self.last_name}"
        return self.first_name
    
    @property
    def display_name(self) -> str:
        """Get user's display name (username or full name)"""
        if self.username:
            return f"@{self.username}"
        return self.full_name
    
    @property
    def total_wealth(self) -> int:
        """Calculate total wealth (toman + bank)"""
        return self.toman + self.bank
    
    @property
    def win_rate(self) -> float:
        """Calculate win rate percentage"""
        if self.total_attacks == 0:
            return 0.0
        return (self.successful_attacks / self.total_attacks) * 100
    
    @property
    def is_online(self) -> bool:
        """Check if user was active in last 5 minutes"""
        if not self.last_seen:
            return False
        delta = datetime.utcnow() - self.last_seen
        return delta.total_seconds() < 300  # 5 minutes
    
    def xp_for_next_level(self) -> int:
        """Calculate XP needed for next level"""
        return 1000 * self.level
    
    def add_xp(self, amount: int) -> tuple[bool, int]:
        """
        Add XP and check for level up
        
        Returns:
            tuple: (leveled_up: bool, levels_gained: int)
        """
        self.xp += amount
        self.total_xp += amount
        
        levels_gained = 0
        while self.xp >= self.xp_for_next_level():
            self.xp -= self.xp_for_next_level()
            self.level += 1
            levels_gained += 1
            
            # Increase max health on level up
            self.max_health += 10
            self.health = self.max_health
        
        return (levels_gained > 0, levels_gained)
    
    def can_afford(self, cost: int) -> bool:
        """Check if user can afford something"""
        return self.toman >= cost
    
    def deduct_toman(self, amount: int) -> bool:
        """Deduct toman if possible"""
        if self.can_afford(amount):
            self.toman -= amount
            return True
        return False
    
    def add_toman(self, amount: int):
        """Add toman to user"""
        self.toman += amount
    
    def add_ruby(self, amount: int):
        """Add ruby to user"""
        self.ruby += amount
    
    def take_damage(self, damage: int) -> int:
        """
        Apply damage to user, considering shield
        
        Returns:
            int: Actual damage taken
        """
        actual_damage = damage
        
        # Shield absorbs damage first
        if self.shield > 0:
            if self.shield >= damage:
                self.shield -= damage
                actual_damage = 0
            else:
                actual_damage = damage - self.shield
                self.shield = 0
        
        # Apply remaining damage to health
        if actual_damage > 0:
            self.health = max(0, self.health - actual_damage)
        
        self.total_damage_received += damage
        return actual_damage
    
    def heal(self, amount: int):
        """Heal user"""
        self.health = min(self.max_health, self.health + amount)
    
    def restore_shield(self, amount: int):
        """Restore shield"""
        self.shield = min(self.max_shield, self.shield + amount)
    
    def update_last_seen(self):
        """Update last seen timestamp"""
        self.last_seen = datetime.utcnow()
        self.updated_at = datetime.utcnow()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert user to dictionary"""
        return {
            "id": self.id,
            "username": self.username,
            "full_name": self.full_name,
            "display_name": self.display_name,
            "level": self.level,
            "xp": self.xp,
            "toman": self.toman,
            "bank": self.bank,
            "ruby": self.ruby,
            "trophy": self.trophy,
            "health": self.health,
            "max_health": self.max_health,
            "shield": self.shield,
            "is_vip": self.is_vip,
            "total_attacks": self.total_attacks,
            "successful_attacks": self.successful_attacks,
            "win_rate": self.win_rate,
            "created_at": self.created_at.isoformat(),
            "last_seen": self.last_seen.isoformat()
        }
    
    def __repr__(self) -> str:
        return f"<User(id={self.id}, username={self.username}, level={self.level})>"
