"""
🎮 StarWars Bot - User Service
سرویس مدیریت کاربران
"""

from datetime import datetime, timedelta
from typing import Optional, List, Tuple
from sqlalchemy import select, func, or_, and_
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from models.user import User
from config import settings


class UserService:
    """سرویس مدیریت عملیات کاربران"""
    
    def __init__(self, session: AsyncSession):
        self.session = session
    
    async def get_or_create_user(
        self,
        user_id: int,
        username: Optional[str] = None,
        first_name: str = "User",
        last_name: Optional[str] = None
    ) -> Tuple[User, bool]:
        """
        دریافت یا ایجاد کاربر
        
        Returns:
            tuple: (user, created)
        """
        # Try to get existing user
        result = await self.session.execute(
            select(User).where(User.id == user_id)
        )
        user = result.scalar_one_or_none()
        
        if user:
            # Update info if changed
            user.username = username
            user.first_name = first_name
            user.last_name = last_name
            user.update_last_seen()
            return user, False
        
        # Create new user
        user = User(
            id=user_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
            toman=settings.INITIAL_BALANCE,
            health=settings.INITIAL_HEALTH,
            max_health=settings.INITIAL_HEALTH,
            level=settings.INITIAL_LEVEL,
            xp=settings.INITIAL_XP
        )
        
        self.session.add(user)
        await self.session.flush()
        
        logger.info(f"✅ New user created: {user_id} (@{username})")
        return user, True
    
    async def get_user(self, user_id: int) -> Optional[User]:
        """دریافت کاربر با ID"""
        result = await self.session.execute(
            select(User).where(User.id == user_id)
        )
        return result.scalar_one_or_none()
    
    async def get_user_by_username(self, username: str) -> Optional[User]:
        """دریافت کاربر با username"""
        result = await self.session.execute(
            select(User).where(User.username == username.replace('@', ''))
        )
        return result.scalar_one_or_none()
    
    async def update_user(self, user: User):
        """بروزرسانی کاربر"""
        user.updated_at = datetime.utcnow()
        await self.session.flush()
    
    async def get_leaderboard(
        self,
        limit: int = 10,
        order_by: str = "toman"
    ) -> List[User]:
        """
        دریافت رتبه‌بندی
        
        Args:
            limit: تعداد کاربران
            order_by: مرتب‌سازی بر اساس (toman, trophy, level)
        """
        order_column = getattr(User, order_by, User.toman)
        
        result = await self.session.execute(
            select(User)
            .where(User.is_active == True)
            .order_by(order_column.desc())
            .limit(limit)
        )
        return list(result.scalars().all())
    
    async def get_user_rank(self, user_id: int, order_by: str = "toman") -> int:
        """دریافت رتبه کاربر"""
        order_column = getattr(User, order_by, User.toman)
        
        user = await self.get_user(user_id)
        if not user:
            return 0
        
        user_value = getattr(user, order_by, 0)
        
        result = await self.session.execute(
            select(func.count(User.id))
            .where(
                and_(
                    User.is_active == True,
                    order_column > user_value
                )
            )
        )
        count = result.scalar_one()
        return count + 1
    
    async def add_toman(self, user_id: int, amount: int) -> bool:
        """اضافه کردن تومان"""
        user = await self.get_user(user_id)
        if not user:
            return False
        
        user.add_toman(amount)
        await self.update_user(user)
        return True
    
    async def deduct_toman(self, user_id: int, amount: int) -> bool:
        """کم کردن تومان"""
        user = await self.get_user(user_id)
        if not user:
            return False
        
        if user.deduct_toman(amount):
            await self.update_user(user)
            return True
        return False
    
    async def add_ruby(self, user_id: int, amount: int) -> bool:
        """اضافه کردن یاقوت"""
        user = await self.get_user(user_id)
        if not user:
            return False
        
        user.add_ruby(amount)
        await self.update_user(user)
        return True
    
    async def add_xp(self, user_id: int, amount: int) -> Tuple[bool, int]:
        """
        اضافه کردن تجربه
        
        Returns:
            tuple: (leveled_up, levels_gained)
        """
        user = await self.get_user(user_id)
        if not user:
            return False, 0
        
        leveled_up, levels = user.add_xp(amount)
        await self.update_user(user)
        return leveled_up, levels
    
    async def check_cooldown(
        self,
        user_id: int,
        cooldown_type: str
    ) -> Tuple[bool, int]:
        """
        بررسی cooldown
        
        Args:
            cooldown_type: نوع (work, coin, daily, mine, attack)
        
        Returns:
            tuple: (can_use, remaining_seconds)
        """
        user = await self.get_user(user_id)
        if not user:
            return False, 0
        
        # Get cooldown duration
        cooldown_map = {
            "work": settings.WORK_COOLDOWN,
            "coin": settings.COIN_COOLDOWN,
            "daily": settings.DAILY_COOLDOWN,
            "mine": settings.MINE_RUBY_COOLDOWN,
            "attack": 0  # Will be based on weapon
        }
        
        cooldown_duration = cooldown_map.get(cooldown_type, 0)
        
        # Get last use time
        last_use_map = {
            "work": user.last_work,
            "coin": user.last_coin,
            "daily": user.last_daily,
            "mine": user.last_mine,
            "attack": user.last_attack
        }
        
        last_use = last_use_map.get(cooldown_type)
        
        if not last_use:
            return True, 0
        
        time_passed = (datetime.utcnow() - last_use).total_seconds()
        remaining = int(cooldown_duration - time_passed)
        
        if remaining <= 0:
            return True, 0
        
        return False, remaining
    
    async def set_cooldown(self, user_id: int, cooldown_type: str):
        """تنظیم cooldown"""
        user = await self.get_user(user_id)
        if not user:
            return
        
        now = datetime.utcnow()
        
        if cooldown_type == "work":
            user.last_work = now
        elif cooldown_type == "coin":
            user.last_coin = now
        elif cooldown_type == "daily":
            user.last_daily = now
        elif cooldown_type == "mine":
            user.last_mine = now
        elif cooldown_type == "attack":
            user.last_attack = now
        
        await self.update_user(user)
    
    async def ban_user(self, user_id: int, banned: bool = True):
        """بن کردن کاربر"""
        user = await self.get_user(user_id)
        if not user:
            return False
        
        user.is_banned = banned
        user.is_active = not banned
        await self.update_user(user)
        return True
    
    async def give_vip(
        self,
        user_id: int,
        level: int = 1,
        days: int = 30
    ) -> bool:
        """دادن VIP به کاربر"""
        user = await self.get_user(user_id)
        if not user:
            return False
        
        user.is_vip = True
        user.vip_level = level
        user.vip_expires_at = datetime.utcnow() + timedelta(days=days)
        
        await self.update_user(user)
        return True
    
    async def check_and_update_vip(self, user_id: int) -> bool:
        """بررسی انقضای VIP"""
        user = await self.get_user(user_id)
        if not user or not user.is_vip:
            return False
        
        if user.vip_expires_at and datetime.utcnow() > user.vip_expires_at:
            user.is_vip = False
            user.vip_level = 0
            await self.update_user(user)
            return False
        
        return True
    
    async def get_total_users(self) -> int:
        """دریافت تعداد کل کاربران"""
        result = await self.session.execute(
            select(func.count(User.id))
        )
        return result.scalar_one()
    
    async def get_active_users(self, hours: int = 24) -> int:
        """دریافت تعداد کاربران فعال"""
        time_threshold = datetime.utcnow() - timedelta(hours=hours)
        
        result = await self.session.execute(
            select(func.count(User.id))
            .where(User.last_seen >= time_threshold)
        )
        return result.scalar_one()
    
    async def search_users(
        self,
        query: str,
        limit: int = 10
    ) -> List[User]:
        """جستجوی کاربران"""
        result = await self.session.execute(
            select(User)
            .where(
                or_(
                    User.username.ilike(f"%{query}%"),
                    User.first_name.ilike(f"%{query}%"),
                    User.last_name.ilike(f"%{query}%")
                )
            )
            .limit(limit)
        )
        return list(result.scalars().all())
