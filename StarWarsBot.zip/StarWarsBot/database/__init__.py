"""
🎮 StarWars Bot - Database Module
ماژول پایگاه داده - برای توسعه آینده
"""

__all__ = []
