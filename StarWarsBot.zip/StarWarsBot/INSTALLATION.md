# 🎮 ربات جنگ ستارگان - راهنمای کامل نصب و اجرا

<div dir="rtl">

## 📦 محتویات پروژه

شما یک ربات کامل و حرفه‌ای دریافت کرده‌اید که شامل موارد زیر است:

### ✅ ویژگی‌های پیاده‌سازی شده:

1. **سیستم اقتصادی کامل**
   - کار کردن و کسب درآمد
   - دریافت سکه رایگان
   - جایزه روزانه
   - استخراج یاقوت
   - سیستم بانکی

2. **سیستم تجهیزات جنگی**
   - 7 نوع موشک (فاتح، عماد، سجیل، خیبرشکن، شهاب، قدر، هسته‌ای)
   - 3 نوع تانک (تی-72، آبرامز، ذوالفقار)
   - 3 نوع جنگنده (اف-16، سوخو-35، کوثر)
   - 3 نوع کشتی جنگی (ناوچه، ناوشکن، زیردریایی)
   - 2 نوع پهپاد (شاهد-136، آرش)

3. **سیستم دفاعی**
   - پدافند هوایی
   - رادار
   - سامانه موشکی
   - گنبد آهنین

4. **سیستم بازی**
   - سیستم سطح و تجربه
   - رتبه‌بندی و لیدربورد
   - پروفایل کاربری کامل
   - آمار نبرد

5. **سیستم ادمین**
   - پنل مدیریت
   - مشاهده آمار
   - مدیریت کاربران
   - ارسال پیام همگانی

6. **امکانات پیشرفته**
   - سیستم VIP چند سطحی
   - جعبه شانس خودکار
   - سیستم Cooldown هوشمند
   - دیتابیس SQLite Async
   - پشتیبانی از Redis (اختیاری)

---

## 🚀 نصب سریع (5 دقیقه)

### پیش‌نیاز:
- VPS با Ubuntu 24
- Python 3.10 یا بالاتر
- دسترسی root

### گام به گام:

```bash
# 1. اتصال به VPS
ssh root@YOUR_VPS_IP

# 2. آپدیت سیستم
apt update && apt upgrade -y

# 3. نصب Python و ابزارها
apt install python3 python3-venv python3-pip git nano wget curl -y

# 4. دانلود پروژه
cd /root
# اینجا فایل StarWarsBot.tar.gz را آپلود کنید و سپس:
tar -xzf StarWarsBot.tar.gz
cd StarWarsBot

# 5. اجرای نصب خودکار
chmod +x install.sh
./install.sh

# 6. پیکربندی
nano .env
# BOT_TOKEN و سایر تنظیمات را وارد کنید

# 7. راه‌اندازی
./start.sh

# 8. بررسی لاگ
tail -f logs/bot_output.log
```

**✅ تمام! ربات شما آماده است!**

---

## ⚙️ پیکربندی دقیق

### 1. دریافت BOT_TOKEN

1. به [@BotFather](https://t.me/BotFather) در تلگرام پیام دهید
2. دستور `/newbot` را بزنید
3. نام و username ربات را وارد کنید
4. توکن دریافتی را کپی کنید

### 2. دریافت User ID

1. به [@userinfobot](https://t.me/userinfobot) پیام دهید
2. User ID خود را دریافت کنید

### 3. ویرایش .env

```bash
nano .env
```

**حداقل تنظیمات:**

```env
BOT_TOKEN=123456:ABC-DEF-YOUR-REAL-TOKEN
OWNER_IDS=YOUR_USER_ID
SECRET_KEY=your_random_secret_key_here
JWT_SECRET=your_random_jwt_secret_here
ENCRYPTION_KEY=your_random_encryption_key_here
```

**تولید کلیدهای امنیتی:**

```bash
python3 -c "import secrets; print('SECRET_KEY=' + secrets.token_urlsafe(32))"
python3 -c "import secrets; print('JWT_SECRET=' + secrets.token_urlsafe(32))"
python3 -c "import secrets; print('ENCRYPTION_KEY=' + secrets.token_urlsafe(32))"
```

---

## 🔧 مدیریت ربات

### راه‌اندازی

```bash
./start.sh
```

### توقف

```bash
./stop.sh
```

### ری‌استارت

```bash
./stop.sh && ./start.sh
```

### مشاهده لاگ‌ها

```bash
# لاگ خروجی
tail -f logs/bot_output.log

# لاگ اصلی
tail -f logs/starwars_bot.log

# مشاهده زنده
watch -n 1 'tail -20 logs/starwars_bot.log'
```

### بررسی وضعیت

```bash
# بررسی پروسه
ps aux | grep python

# بررسی PID
cat bot.pid
```

---

## 🛡️ نصب به عنوان سرویس (توصیه می‌شود)

این روش باعث می‌شود ربات حتی بعد از ری‌استارت سرور به صورت خودکار اجرا شود.

### گام 1: کپی فایل سرویس

```bash
cp starwarsbot.service /etc/systemd/system/
```

### گام 2: ویرایش مسیرها (در صورت نیاز)

```bash
nano /etc/systemd/system/starwarsbot.service
```

مطمئن شوید مسیرها صحیح هستند:
- `WorkingDirectory`: مسیر پروژه
- `ExecStart`: مسیر Python و main.py

### گام 3: فعال‌سازی

```bash
systemctl daemon-reload
systemctl enable starwarsbot
systemctl start starwarsbot
```

### گام 4: بررسی وضعیت

```bash
systemctl status starwarsbot
```

### دستورات مدیریت سرویس:

```bash
# شروع
systemctl start starwarsbot

# توقف
systemctl stop starwarsbot

# ری‌استارت
systemctl restart starwarsbot

# مشاهده لاگ
journalctl -u starwarsbot -f

# غیرفعال کردن
systemctl disable starwarsbot
```

---

## 📊 تست و بررسی

### تست خودکار

```bash
python3 test.py
```

این اسکریپت موارد زیر را بررسی می‌کند:
- ✅ Import ماژول‌ها
- ✅ تنظیمات
- ✅ اتصال دیتابیس
- ✅ توابع کمکی
- ✅ پیکربندی بازی

### تست دستی

1. به ربات در تلگرام پیام `/start` بدهید
2. اگر منوی زیبا دریافت کردید، ✅ OK
3. دستورات زیر را امتحان کنید:
   - `/help` - راهنما
   - `/profile` - پروفایل
   - `/coin` - دریافت سکه
   - `/shop` - فروشگاه

---

## 🐛 رفع مشکلات

### مشکل 1: ربات اجرا نمی‌شود

**علائم:**
- خطا در start.sh
- پروسه متوقف می‌شود

**راه حل:**

```bash
# بررسی لاگ‌ها
tail -100 logs/bot_output.log

# بررسی خطاهای Python
python3 main.py
```

**احتمالات:**
1. توکن اشتباه → بررسی `.env`
2. کتابخانه‌ها نصب نیست → `source venv/bin/activate && pip install -r requirements.txt`
3. مشکل دیتابیس → `rm starwars_bot.db` و دوباره اجرا

### مشکل 2: خطای ModuleNotFoundError

```bash
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
deactivate
./start.sh
```

### مشکل 3: Permission Denied

```bash
chmod +x install.sh start.sh stop.sh test.py
```

### مشکل 4: ربات پاسخ نمی‌دهد

**بررسی:**

```bash
# آیا ربات در حال اجرا است؟
ps aux | grep python

# آیا لاگ‌ها خطا دارند?
tail -50 logs/starwars_bot.log
```

**علل احتمالی:**
1. توکن نامعتبر
2. اینترنت VPS قطع است
3. فیلترینگ تلگرام

### مشکل 5: دیتابیس خراب شد

```bash
# پشتیبان
cp starwars_bot.db backups/backup_$(date +%Y%m%d_%H%M%S).db

# حذف و ایجاد مجدد
rm starwars_bot.db
python3 main.py  # یکبار اجرا کن تا دیتابیس بسازه
./start.sh
```

---

## 🔐 امنیت

### 1. محافظت از فایل .env

```bash
chmod 600 .env
```

### 2. فایروال

```bash
apt install ufw -y
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP (در صورت نیاز)
ufw allow 443/tcp   # HTTPS (در صورت نیاز)
ufw enable
```

### 3. تغییر پورت SSH (توصیه می‌شود)

```bash
nano /etc/ssh/sshd_config
# Port را به عدد دیگری تغییر دهید (مثلا 2222)
systemctl restart sshd
ufw allow 2222/tcp
```

### 4. پشتیبان‌گیری خودکار

ایجاد اسکریپت backup:

```bash
nano backup.sh
```

محتوا:

```bash
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
tar -czf backups/backup_$DATE.tar.gz starwars_bot.db .env logs/
find backups/ -mtime +7 -delete
```

اجرای روزانه:

```bash
chmod +x backup.sh
crontab -e
# اضافه کنید:
0 3 * * * /root/StarWarsBot/backup.sh
```

---

## 📈 مانیتورینگ

### 1. استفاده از htop

```bash
apt install htop -y
htop
```

### 2. مشاهده استفاده منابع

```bash
# CPU و RAM
free -h
top -bn1 | grep "Cpu(s)"

# دیسک
df -h
```

### 3. تعداد کاربران فعال

از پنل ادمین ربات:
- `/admin` → آمار

---

## 🚀 بهینه‌سازی

### 1. افزایش حافظه Python

در `starwarsbot.service`:

```ini
Environment="PYTHONUNBUFFERED=1"
Environment="PYTHONOPTIMIZE=1"
```

### 2. استفاده از Redis (اختیاری)

```bash
# نصب Redis
apt install redis-server -y
systemctl enable redis-server
systemctl start redis-server

# فعال کردن در .env
REDIS_ENABLED=true
REDIS_HOST=localhost
REDIS_PORT=6379
```

### 3. PostgreSQL به جای SQLite (اختیاری)

برای حجم بالای کاربران:

```bash
apt install postgresql -y
sudo -u postgres createdb starwarsbot

# در .env:
DATABASE_URL=postgresql+asyncpg://user:pass@localhost/starwarsbot
```

---

## 📚 دستورات مفید

```bash
# مشاهده همه پروسه‌های Python
ps aux | grep python

# Kill یک پروسه
kill -9 PID

# مشاهده حافظه استفاده شده
du -sh StarWarsBot/

# پاک کردن لاگ‌های قدیمی
find logs/ -name "*.log.*" -mtime +30 -delete

# بررسی نسخه Python
python3 --version

# لیست بسته‌های نصب شده
source venv/bin/activate
pip list
```

---

## 💡 نکات مهم

1. **همیشه** قبل از تغییرات از دیتابیس backup بگیرید
2. لاگ‌ها را منظم چک کنید
3. از رمزهای قوی استفاده کنید
4. به کاربران عادی دسترسی ادمین ندهید
5. هر 2 هفته یکبار VPS را آپدیت کنید

---

## 🆘 پشتیبانی

اگر مشکلی داشتید:

1. ابتدا لاگ‌ها را بررسی کنید
2. از اسکریپت test.py استفاده کنید
3. تنظیمات .env را دوباره چک کنید
4. اگر حل نشد، با پشتیبانی تماس بگیرید

---

## ✅ چک‌لیست نهایی

قبل از استفاده عمومی:

- [ ] توکن ربات درست است
- [ ] Owner ID ست شده
- [ ] ربات به درستی راه‌اندازی می‌شود
- [ ] تمام دستورات کار می‌کنند
- [ ] systemd service راه‌اندازی شده
- [ ] backup خودکار فعال است
- [ ] فایروال تنظیم شده
- [ ] لاگ‌ها را مانیتور می‌کنید

---

## 🎉 تبریک!

ربات جنگ ستارگان شما آماده است! 🚀

از بازی لذت ببرید! 🎮

</div>
