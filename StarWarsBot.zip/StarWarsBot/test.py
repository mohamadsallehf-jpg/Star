#!/usr/bin/env python3
"""
🎮 StarWars Bot - Test Script
اسکریپت تست برای بررسی صحت کد
"""

import sys
import os
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

def test_imports():
    """Test if all imports work"""
    print("📦 Testing imports...")
    
    try:
        from config import settings, game_config
        print("✅ Config imported successfully")
    except Exception as e:
        print(f"❌ Failed to import config: {e}")
        return False
    
    try:
        from models.base import db_manager
        from models.user import User
        print("✅ Models imported successfully")
    except Exception as e:
        print(f"❌ Failed to import models: {e}")
        return False
    
    try:
        from services.user_service import UserService
        print("✅ Services imported successfully")
    except Exception as e:
        print(f"❌ Failed to import services: {e}")
        return False
    
    try:
        from utils.helpers import format_number, format_time_delta
        print("✅ Utils imported successfully")
    except Exception as e:
        print(f"❌ Failed to import utils: {e}")
        return False
    
    return True


def test_settings():
    """Test if settings are valid"""
    print("\n⚙️  Testing settings...")
    
    try:
        from config import settings
        
        # Check critical settings
        if not settings.BOT_TOKEN or settings.BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
            print("⚠️  BOT_TOKEN not configured in .env")
            return False
        
        print(f"✅ BOT_TOKEN: {settings.BOT_TOKEN[:10]}...")
        print(f"✅ Database: {settings.DATABASE_URL}")
        print(f"✅ Redis: {settings.REDIS_ENABLED}")
        print(f"✅ Logging: {settings.LOG_LEVEL}")
        
        return True
    except Exception as e:
        print(f"❌ Settings error: {e}")
        return False


def test_database():
    """Test database connection"""
    print("\n💾 Testing database...")
    
    try:
        import asyncio
        from models.base import db_manager
        
        async def test_db():
            try:
                await db_manager.init()
                print("✅ Database initialized successfully")
                
                # Test session
                async with db_manager.session() as session:
                    print("✅ Database session created successfully")
                
                await db_manager.close()
                print("✅ Database closed successfully")
                
                return True
            except Exception as e:
                print(f"❌ Database error: {e}")
                return False
        
        return asyncio.run(test_db())
    except Exception as e:
        print(f"❌ Failed to test database: {e}")
        return False


def test_helpers():
    """Test helper functions"""
    print("\n🔧 Testing helper functions...")
    
    try:
        from utils.helpers import (
            format_number,
            format_time_delta,
            generate_progress_bar,
            get_rank_emoji
        )
        
        # Test format_number
        assert format_number(1000) == "1,000"
        assert format_number(1000000) == "1,000,000"
        print("✅ format_number works")
        
        # Test format_time_delta
        assert "ثانیه" in format_time_delta(30)
        assert "دقیقه" in format_time_delta(120)
        print("✅ format_time_delta works")
        
        # Test progress bar
        bar = generate_progress_bar(50, 100)
        assert "50%" in bar
        print("✅ generate_progress_bar works")
        
        # Test rank emoji
        assert get_rank_emoji(1) == "🥇"
        assert get_rank_emoji(2) == "🥈"
        print("✅ get_rank_emoji works")
        
        return True
    except Exception as e:
        print(f"❌ Helper functions error: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_game_config():
    """Test game configuration"""
    print("\n🎮 Testing game configuration...")
    
    try:
        from config import game_config
        
        # Test missiles
        assert len(game_config.MISSILES) > 0
        print(f"✅ {len(game_config.MISSILES)} missiles configured")
        
        # Test tanks
        assert len(game_config.TANKS) > 0
        print(f"✅ {len(game_config.TANKS)} tanks configured")
        
        # Test fighters
        assert len(game_config.FIGHTERS) > 0
        print(f"✅ {len(game_config.FIGHTERS)} fighters configured")
        
        # Test warships
        assert len(game_config.WARSHIPS) > 0
        print(f"✅ {len(game_config.WARSHIPS)} warships configured")
        
        # Validate missile data
        for name, data in game_config.MISSILES.items():
            assert "damage" in data
            assert "cost" in data
            assert "required_level" in data
        print("✅ All missile data is valid")
        
        return True
    except Exception as e:
        print(f"❌ Game config error: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all tests"""
    print("=" * 60)
    print("🎮 StarWars Bot - Test Suite")
    print("=" * 60)
    
    tests = [
        ("Imports", test_imports),
        ("Settings", test_settings),
        ("Database", test_database),
        ("Helpers", test_helpers),
        ("Game Config", test_game_config),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"\n❌ Test '{name}' crashed: {e}")
            results.append((name, False))
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 Test Summary")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {name}")
    
    print("=" * 60)
    print(f"Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed!")
        return 0
    else:
        print("⚠️  Some tests failed!")
        return 1


if __name__ == "__main__":
    sys.exit(main())
