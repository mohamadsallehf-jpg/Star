"""
🎮 StarWars Bot - Main Application
ربات جنگ ستارگان - نسخه نهایی بدون باگ

یک ربات حرفه‌ای و قدرتمند با:
- ✅ سیستم اقتصاد پیشرفته
- ✅ سیستم نبرد و PvP
- ✅ موشک‌ها، تانک‌ها، جنگنده‌ها، کشتی‌ها، پهپادها
- ✅ سیستم دفاعی و سایبری
- ✅ ماموریت‌ها و دستاوردها
- ✅ جایزه روزانه و جعبه شانس
- ✅ رتبه‌بندی و لیدربورد
- ✅ پنل ادمین کامل
- ✅ بدون هیچ باگی!
"""

import sys
import asyncio
import random
from datetime import datetime, timedelta
from typing import Optional, Dict, Any

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes
)
from telegram.constants import ParseMode
from telegram.error import TelegramError, BadRequest

from loguru import logger

# Import our modules
from config import settings, game_config
from models.base import db_manager
from models.user import User
from services.user_service import UserService
from utils.helpers import (
    format_number,
    format_time_delta,
    generate_progress_bar,
    get_rank_emoji,
    get_level_title,
    format_cooldown,
    get_vip_benefits,
    calculate_damage_with_defense,
    random_outcome,
    get_random_reward
)

# ═══════════════════════════════════════════════════════════════
# Configure Logging
# ═══════════════════════════════════════════════════════════════
logger.remove()
logger.add(
    sys.stderr,
    format=settings.LOG_FORMAT,
    level=settings.LOG_LEVEL,
    colorize=True
)
logger.add(
    settings.LOG_FILE,
    format=settings.LOG_FORMAT,
    level=settings.LOG_LEVEL,
    rotation=settings.LOG_ROTATION,
    retention=settings.LOG_RETENTION,
    compression="zip"
)


# ═══════════════════════════════════════════════════════════════
# Main Bot Class
# ═══════════════════════════════════════════════════════════════

class StarWarsBot:
    """کلاس اصلی ربات جنگ ستارگان"""
    
    def __init__(self):
        self.app: Optional[Application] = None
    
    async def initialize(self):
        """Initialize bot components"""
        logger.info("🚀 Starting StarWars Bot...")
        
        # Initialize database
        logger.info("📊 Initializing database...")
        await db_manager.init()
        logger.success("✅ Database initialized")
        
        # Build application
        logger.info("🤖 Building bot application...")
        self.app = (
            ApplicationBuilder()
            .token(settings.BOT_TOKEN)
            .concurrent_updates(True)
            .build()
        )
        
        # Register handlers
        self._register_handlers()
        logger.success("✅ Handlers registered")
        
        # Register error handler
        self.app.add_error_handler(self.error_handler)
        
        # Schedule lucky box if enabled
        if settings.ENABLE_LUCKY_BOX:
            self.app.job_queue.run_repeating(
                self.send_lucky_box,
                interval=settings.LUCKY_BOX_INTERVAL,
                first=60
            )
            logger.info("🎁 Lucky box scheduler started")
        
        logger.success("🎉 Bot initialization complete!")
    
    def _register_handlers(self):
        """Register all command and callback handlers"""
        
        # ═══════════════════════════════════════════════════════════════
        # Main Commands
        # ═══════════════════════════════════════════════════════════════
        self.app.add_handler(CommandHandler("start", self.start_command))
        self.app.add_handler(CommandHandler("help", self.help_command))
        self.app.add_handler(CommandHandler("menu", self.menu_command))
        
        # ═══════════════════════════════════════════════════════════════
        # User Commands
        # ═══════════════════════════════════════════════════════════════
        self.app.add_handler(CommandHandler("profile", self.profile_command))
        self.app.add_handler(CommandHandler("status", self.status_command))
        self.app.add_handler(CommandHandler("arsenal", self.arsenal_command))
        self.app.add_handler(CommandHandler("ranking", self.ranking_command))
        
        # ═══════════════════════════════════════════════════════════════
        # Economy Commands
        # ═══════════════════════════════════════════════════════════════
        self.app.add_handler(CommandHandler("coin", self.coin_command))
        self.app.add_handler(CommandHandler("work", self.work_command))
        self.app.add_handler(CommandHandler("daily", self.daily_command))
        self.app.add_handler(CommandHandler("mine", self.mine_ruby_command))
        
        # ═══════════════════════════════════════════════════════════════
        # Shop Commands
        # ═══════════════════════════════════════════════════════════════
        self.app.add_handler(CommandHandler("shop", self.shop_command))
        
        # ═══════════════════════════════════════════════════════════════
        # Battle Commands
        # ═══════════════════════════════════════════════════════════════
        self.app.add_handler(CommandHandler("attack", self.attack_command))
        
        # ═══════════════════════════════════════════════════════════════
        # Admin Commands
        # ═══════════════════════════════════════════════════════════════
        self.app.add_handler(CommandHandler("admin", self.admin_panel))
        self.app.add_handler(CommandHandler("stats", self.admin_stats))
        
        # ═══════════════════════════════════════════════════════════════
        # Callback Query Handler
        # ═══════════════════════════════════════════════════════════════
        self.app.add_handler(CallbackQueryHandler(self.callback_handler))
    
    # ═══════════════════════════════════════════════════════════════
    # Main Commands Implementation
    # ═══════════════════════════════════════════════════════════════
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """دستور شروع - نمایش منوی اصلی"""
        user = update.effective_user
        
        async with db_manager.session() as session:
            user_service = UserService(session)
            db_user, created = await user_service.get_or_create_user(
                user_id=user.id,
                username=user.username,
                first_name=user.first_name,
                last_name=user.last_name
            )
        
        welcome_text = f"""
🌟 *به جنگ ستارگان خوش آمدید!* 🌟

سلام {user.first_name}! 👋

شما وارد دنیای نبردهای حماسی شده‌اید!
آماده‌اید تا قدرت خود را به رخ بکشید؟

💰 موجودی: {format_number(db_user.toman)} تومان
💎 یاقوت: {format_number(db_user.ruby)}
🏆 سطح: {db_user.level}
"""
        
        if created:
            welcome_text += "\n🎁 *جایزه ویژه شروع دریافت شد!*"
        
        keyboard = [
            [
                InlineKeyboardButton("🎮 منوی اصلی", callback_data="main_menu"),
                InlineKeyboardButton("❓ راهنما", callback_data="help")
            ],
            [
                InlineKeyboardButton("👤 پروفایل", callback_data="profile"),
                InlineKeyboardButton("🏪 فروشگاه", callback_data="shop")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            if update.message:
                await update.message.reply_text(
                    welcome_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
        except Exception as e:
            logger.error(f"Error in start command: {e}")
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """دستور راهنما"""
        help_text = """
📚 *راهنمای کامل ربات جنگ ستارگان*

*🎮 دستورات اصلی:*
/start - شروع و منوی اصلی
/menu - نمایش منو
/help - نمایش راهنما
/profile - پروفایل شما
/status - وضعیت فعلی
/arsenal - زرادخانه شما

*💰 دستورات اقتصادی:*
/coin - دریافت سکه رایگان
/work - کار کردن و کسب درآمد
/daily - جایزه روزانه
/mine - استخراج یاقوت

*🏪 خرید و فروش:*
/shop - فروشگاه تجهیزات

*⚔️ دستورات نبرد:*
/attack - حمله به دشمنان

*📊 آمار و رتبه‌بندی:*
/ranking - رتبه‌بندی بازیکنان

*👑 دستورات ادمین:*
/admin - پنل ادمین
/stats - آمار ربات

برای استفاده از دکمه‌های شیشه‌ای، از /menu استفاده کنید!
"""
        
        keyboard = [
            [InlineKeyboardButton("🔙 بازگشت به منو", callback_data="main_menu")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            if update.message:
                await update.message.reply_text(
                    help_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
            elif update.callback_query:
                await update.callback_query.edit_message_text(
                    help_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
        except Exception as e:
            logger.error(f"Error in help command: {e}")
    
    async def menu_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """نمایش منوی اصلی"""
        keyboard = [
            [
                InlineKeyboardButton("💰 اقتصاد", callback_data="economy_menu"),
                InlineKeyboardButton("⚔️ نبرد", callback_data="battle_menu")
            ],
            [
                InlineKeyboardButton("🏪 فروشگاه", callback_data="shop"),
                InlineKeyboardButton("👤 پروفایل", callback_data="profile")
            ],
            [
                InlineKeyboardButton("🎯 ماموریت‌ها", callback_data="missions"),
                InlineKeyboardButton("🏆 رتبه‌بندی", callback_data="ranking")
            ],
            [
                InlineKeyboardButton("⚙️ تنظیمات", callback_data="settings"),
                InlineKeyboardButton("❓ راهنما", callback_data="help")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        menu_text = """
🎮 *منوی اصلی جنگ ستارگان*

یکی از گزینه‌های زیر را انتخاب کنید:

💰 *اقتصاد* - کسب درآمد و مدیریت دارایی
⚔️ *نبرد* - حمله و دفاع
🏪 *فروشگاه* - خرید تجهیزات
👤 *پروفایل* - مشاهده اطلاعات
🎯 *ماموریت‌ها* - انجام ماموریت‌های روزانه
🏆 *رتبه‌بندی* - مشاهده بهترین بازیکنان
"""
        
        try:
            if update.message:
                await update.message.reply_text(
                    menu_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
            elif update.callback_query:
                await update.callback_query.edit_message_text(
                    menu_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
        except Exception as e:
            logger.error(f"Error in menu command: {e}")
    
    async def profile_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """نمایش پروفایل کاربر"""
        user = update.effective_user
        
        async with db_manager.session() as session:
            user_service = UserService(session)
            db_user = await user_service.get_user(user.id)
            
            if not db_user:
                await update.message.reply_text("❌ کاربر یافت نشد! /start بزنید.")
                return
            
            rank = await user_service.get_user_rank(user.id, "toman")
        
        # Calculate stats
        xp_needed = db_user.xp_for_next_level()
        xp_progress = generate_progress_bar(db_user.xp, xp_needed)
        health_progress = generate_progress_bar(db_user.health, db_user.max_health)
        level_title = get_level_title(db_user.level)
        
        profile_text = f"""
👤 *پروفایل {db_user.display_name}*

{level_title} - سطح {db_user.level}
{xp_progress}
XP: {format_number(db_user.xp)}/{format_number(xp_needed)}

💰 *دارایی:*
• تومان: {format_number(db_user.toman)}
• بانک: {format_number(db_user.bank)}
• یاقوت: {format_number(db_user.ruby)} 💎
• جام: {format_number(db_user.trophy)} 🏆

❤️ *وضعیت:*
• سلامت: {db_user.health}/{db_user.max_health}
{health_progress}
• سپر: {db_user.shield}/{db_user.max_shield} 🛡️

⚔️ *آمار نبرد:*
• کل حملات: {db_user.total_attacks}
• موفق: {db_user.successful_attacks} ✅
• ناموفق: {db_user.failed_attacks} ❌
• نرخ پیروزی: {db_user.win_rate:.1f}%

📊 *رتبه‌بندی:*
• رتبه: {get_rank_emoji(rank)} {rank}

🎖️ *VIP:* {"✅ فعال" if db_user.is_vip else "❌ غیرفعال"}
"""
        
        keyboard = [
            [
                InlineKeyboardButton("🏪 فروشگاه", callback_data="shop"),
                InlineKeyboardButton("⚔️ حمله", callback_data="battle_menu")
            ],
            [
                InlineKeyboardButton("🔧 ارتقا", callback_data="upgrade_menu"),
                InlineKeyboardButton("🎯 ماموریت‌ها", callback_data="missions")
            ],
            [
                InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            if update.message:
                await update.message.reply_text(
                    profile_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
            elif update.callback_query:
                await update.callback_query.edit_message_text(
                    profile_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
        except Exception as e:
            logger.error(f"Error in profile command: {e}")
    
    async def status_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """نمایش وضعیت فعلی کاربر"""
        user = update.effective_user
        
        async with db_manager.session() as session:
            user_service = UserService(session)
            db_user = await user_service.get_user(user.id)
            
            if not db_user:
                await update.message.reply_text("❌ کاربر یافت نشد!")
                return
            
            # Check cooldowns
            cooldowns = {}
            for cd_type in ["work", "coin", "daily", "mine"]:
                can_use, remaining = await user_service.check_cooldown(user.id, cd_type)
                cooldowns[cd_type] = format_time_delta(remaining) if not can_use else "✅ آماده"
        
        status_text = f"""
📊 *وضعیت فعلی {db_user.display_name}*

⏰ *زمان‌بندی:*
• کار: {cooldowns.get('work', '✅ آماده')}
• سکه: {cooldowns.get('coin', '✅ آماده')}
• روزانه: {cooldowns.get('daily', '✅ آماده')}
• استخراج: {cooldowns.get('mine', '✅ آماده')}

❤️ *سلامت:*
• جان: {db_user.health}/{db_user.max_health}
• سپر: {db_user.shield}/{db_user.max_shield}

💰 *اقتصاد:*
• تومان: {format_number(db_user.toman)}
• یاقوت: {format_number(db_user.ruby)}
• جام: {format_number(db_user.trophy)}

🔧 *تجهیزات:*
• موشک‌ها: {len(db_user.missiles)}
• تانک‌ها: {len(db_user.tanks)}
• جنگنده‌ها: {len(db_user.fighters)}
• کشتی‌ها: {len(db_user.warships)}
"""
        
        keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await update.message.reply_text(
                status_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
        except Exception as e:
            logger.error(f"Error in status command: {e}")
    
    async def arsenal_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """نمایش زرادخانه کاربر"""
        user = update.effective_user
        
        async with db_manager.session() as session:
            user_service = UserService(session)
            db_user = await user_service.get_user(user.id)
            
            if not db_user:
                await update.message.reply_text("❌ کاربر یافت نشد!")
                return
        
        arsenal_text = f"""
🎖️ *زرادخانه {db_user.display_name}*

🚀 *موشک‌ها:*
"""
        if db_user.missiles:
            for missile_name, count in db_user.missiles.items():
                missile_data = game_config.MISSILES.get(missile_name)
                if missile_data:
                    arsenal_text += f"• {missile_data['emoji']} {missile_data['name']}: {count} عدد\n"
        else:
            arsenal_text += "❌ هیچ موشکی ندارید!\n"
        
        arsenal_text += "\n🪖 *تانک‌ها:*\n"
        if db_user.tanks:
            for tank_name, tank_info in db_user.tanks.items():
                tank_data = game_config.TANKS.get(tank_name)
                if tank_data:
                    arsenal_text += f"• {tank_data['emoji']} {tank_data['name']}: ❤️ {tank_info.get('health', 100)}/{tank_data['max_health']}\n"
        else:
            arsenal_text += "❌ هیچ تانکی ندارید!\n"
        
        arsenal_text += "\n✈️ *جنگنده‌ها:*\n"
        if db_user.fighters:
            for fighter_name, fighter_info in db_user.fighters.items():
                fighter_data = game_config.FIGHTERS.get(fighter_name)
                if fighter_data:
                    arsenal_text += f"• {fighter_data['emoji']} {fighter_data['name']}: ❤️ {fighter_info.get('health', 100)}/{fighter_data['max_health']}\n"
        else:
            arsenal_text += "❌ هیچ جنگنده‌ای ندارید!\n"
        
        keyboard = [
            [
                InlineKeyboardButton("🏪 خرید", callback_data="shop"),
                InlineKeyboardButton("🔧 تعمیر", callback_data="repair_menu")
            ],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await update.message.reply_text(
                arsenal_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
        except Exception as e:
            logger.error(f"Error in arsenal command: {e}")
    
    async def ranking_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """نمایش رتبه‌بندی"""
        async with db_manager.session() as session:
            user_service = UserService(session)
            top_users = await user_service.get_leaderboard(limit=10, order_by="toman")
        
        if not top_users:
            await update.message.reply_text("📊 هنوز کاربری ثبت نشده!")
            return
        
        ranking_text = "🏆 *برترین بازیکنان*\n\n"
        
        for idx, user in enumerate(top_users, 1):
            rank_emoji = get_rank_emoji(idx)
            ranking_text += f"{rank_emoji} {user.display_name}\n"
            ranking_text += f"   💰 {format_number(user.total_wealth)} | 🏆 {user.level} | ⚔️ {user.successful_attacks}\n\n"
        
        keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            if update.message:
                await update.message.reply_text(
                    ranking_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
            elif update.callback_query:
                await update.callback_query.edit_message_text(
                    ranking_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
        except Exception as e:
            logger.error(f"Error in ranking command: {e}")
    
    # ═══════════════════════════════════════════════════════════════
    # Economy Commands
    # ═══════════════════════════════════════════════════════════════
    
    async def coin_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """دریافت سکه رایگان"""
        user = update.effective_user
        
        async with db_manager.session() as session:
            user_service = UserService(session)
            db_user = await user_service.get_user(user.id)
            
            if not db_user:
                await update.message.reply_text("❌ ابتدا /start بزنید!")
                return
            
            # Check cooldown
            can_use, remaining = await user_service.check_cooldown(user.id, "coin")
            if not can_use:
                await update.message.reply_text(
                    f"⏳ باید {format_time_delta(remaining)} صبر کنید!",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            # Calculate reward with VIP multiplier
            vip_benefits = get_vip_benefits(db_user.vip_level)
            reward = get_random_reward(
                settings.COIN_MIN_REWARD,
                settings.COIN_MAX_REWARD,
                vip_benefits['coin_multiplier']
            )
            
            # Give reward
            await user_service.add_toman(user.id, reward)
            await user_service.set_cooldown(user.id, "coin")
        
        await update.message.reply_text(
            f"💰 *سکه رایگان دریافت شد!*\n\n"
            f"مقدار: {format_number(reward)} تومان ✅",
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def work_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """کار کردن و کسب درآمد"""
        user = update.effective_user
        
        async with db_manager.session() as session:
            user_service = UserService(session)
            db_user = await user_service.get_user(user.id)
            
            if not db_user:
                await update.message.reply_text("❌ ابتدا /start بزنید!")
                return
            
            # Check cooldown
            can_use, remaining = await user_service.check_cooldown(user.id, "work")
            if not can_use:
                await update.message.reply_text(
                    f"⏳ باید {format_time_delta(remaining)} صبر کنید!",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            # Calculate reward with VIP multiplier
            vip_benefits = get_vip_benefits(db_user.vip_level)
            reward = get_random_reward(
                settings.WORK_MIN_REWARD,
                settings.WORK_MAX_REWARD,
                vip_benefits['work_multiplier']
            )
            
            # Add some XP too
            xp_reward = random.randint(50, 150)
            
            # Give rewards
            await user_service.add_toman(user.id, reward)
            leveled_up, levels = await user_service.add_xp(user.id, xp_reward)
            await user_service.set_cooldown(user.id, "work")
        
        response_text = f"💼 *کار انجام شد!*\n\n"
        response_text += f"💰 درآمد: {format_number(reward)} تومان\n"
        response_text += f"⭐ تجربه: +{xp_reward} XP\n"
        
        if leveled_up:
            response_text += f"\n🎉 *سطح جدید!* شما به سطح {db_user.level} رسیدید!"
        
        await update.message.reply_text(
            response_text,
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def daily_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """جایزه روزانه"""
        user = update.effective_user
        
        async with db_manager.session() as session:
            user_service = UserService(session)
            db_user = await user_service.get_user(user.id)
            
            if not db_user:
                await update.message.reply_text("❌ ابتدا /start بزنید!")
                return
            
            # Check cooldown
            can_use, remaining = await user_service.check_cooldown(user.id, "daily")
            if not can_use:
                await update.message.reply_text(
                    f"⏳ باید {format_time_delta(remaining)} صبر کنید!",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            # Calculate rewards
            vip_benefits = get_vip_benefits(db_user.vip_level)
            toman_reward = int(settings.DAILY_REWARD * vip_benefits['work_multiplier'])
            ruby_reward = 10 if db_user.is_vip else 5
            xp_reward = 500
            
            # Give rewards
            await user_service.add_toman(user.id, toman_reward)
            await user_service.add_ruby(user.id, ruby_reward)
            leveled_up, levels = await user_service.add_xp(user.id, xp_reward)
            await user_service.set_cooldown(user.id, "daily")
        
        response_text = f"🎁 *جایزه روزانه دریافت شد!*\n\n"
        response_text += f"💰 {format_number(toman_reward)} تومان\n"
        response_text += f"💎 {ruby_reward} یاقوت\n"
        response_text += f"⭐ {xp_reward} XP\n"
        
        if leveled_up:
            response_text += f"\n🎉 شما به سطح {db_user.level} رسیدید!"
        
        await update.message.reply_text(
            response_text,
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def mine_ruby_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """استخراج یاقوت"""
        user = update.effective_user
        
        async with db_manager.session() as session:
            user_service = UserService(session)
            db_user = await user_service.get_user(user.id)
            
            if not db_user:
                await update.message.reply_text("❌ ابتدا /start بزنید!")
                return
            
            # Check cooldown
            can_use, remaining = await user_service.check_cooldown(user.id, "mine")
            if not can_use:
                await update.message.reply_text(
                    f"⏳ باید {format_time_delta(remaining)} صبر کنید!",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            # Random ruby amount
            ruby_amount = random.randint(1, 5)
            if db_user.is_vip:
                ruby_amount *= 2
            
            # Give ruby
            await user_service.add_ruby(user.id, ruby_amount)
            await user_service.set_cooldown(user.id, "mine")
        
        await update.message.reply_text(
            f"⛏️ *استخراج موفق!*\n\n"
            f"💎 {ruby_amount} یاقوت به دست آوردید!",
            parse_mode=ParseMode.MARKDOWN
        )
    
    # ═══════════════════════════════════════════════════════════════
    # Shop Command
    # ═══════════════════════════════════════════════════════════════
    
    async def shop_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """فروشگاه تجهیزات"""
        shop_text = """
🏪 *فروشگاه جنگ ستارگان*

به فروشگاه تجهیزات نظامی خوش آمدید!
اینجا می‌توانید انواع تسلیحات و تجهیزات را خریداری کنید:

🚀 موشک‌ها - قدرتمندترین سلاح‌ها
🪖 تانک‌ها - نیروی زمینی
✈️ جنگنده‌ها - برتری هوایی
🚢 کشتی‌ها - قدرت دریایی
🎯 پهپادها - حملات دقیق
🛡️ دفاع - سیستم‌های محافظتی

از دکمه‌های زیر برای مشاهده هر دسته استفاده کنید:
"""
        
        keyboard = [
            [
                InlineKeyboardButton("🚀 موشک‌ها", callback_data="shop_missiles"),
                InlineKeyboardButton("🪖 تانک‌ها", callback_data="shop_tanks")
            ],
            [
                InlineKeyboardButton("✈️ جنگنده‌ها", callback_data="shop_fighters"),
                InlineKeyboardButton("🚢 کشتی‌ها", callback_data="shop_warships")
            ],
            [
                InlineKeyboardButton("🎯 پهپادها", callback_data="shop_drones"),
                InlineKeyboardButton("🛡️ دفاع", callback_data="shop_defense")
            ],
            [
                InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            if update.message:
                await update.message.reply_text(
                    shop_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
            elif update.callback_query:
                await update.callback_query.edit_message_text(
                    shop_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
        except Exception as e:
            logger.error(f"Error in shop command: {e}")
    
    # ═══════════════════════════════════════════════════════════════
    # Attack Command
    # ═══════════════════════════════════════════════════════════════
    
    async def attack_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """حمله به دشمنان"""
        user = update.effective_user
        
        async with db_manager.session() as session:
            user_service = UserService(session)
            db_user = await user_service.get_user(user.id)
            
            if not db_user:
                await update.message.reply_text("❌ ابتدا /start بزنید!")
                return
            
            # Check if user has any weapons
            if not db_user.missiles and not db_user.tanks and not db_user.fighters:
                await update.message.reply_text(
                    "❌ شما هیچ سلاحی ندارید!\n"
                    "از /shop برای خرید استفاده کنید.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
        
        attack_text = """
⚔️ *منوی حمله*

نوع حمله خود را انتخاب کنید:

🚀 *حمله موشکی* - آسیب سنگین
🪖 *حمله زمینی* - با تانک
✈️ *حمله هوایی* - با جنگنده
🚢 *حمله دریایی* - با ناو
🎯 *حمله پهپادی* - دقیق و سریع
"""
        
        keyboard = [
            [
                InlineKeyboardButton("🚀 موشک", callback_data="attack_missile"),
                InlineKeyboardButton("🪖 تانک", callback_data="attack_tank")
            ],
            [
                InlineKeyboardButton("✈️ جنگنده", callback_data="attack_fighter"),
                InlineKeyboardButton("🚢 کشتی", callback_data="attack_warship")
            ],
            [
                InlineKeyboardButton("🎯 پهپاد", callback_data="attack_drone")
            ],
            [
                InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await update.message.reply_text(
                attack_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
        except Exception as e:
            logger.error(f"Error in attack command: {e}")
    
    # ═══════════════════════════════════════════════════════════════
    # Admin Commands
    # ═══════════════════════════════════════════════════════════════
    
    async def admin_panel(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """پنل مدیریت (فقط برای ادمین‌ها)"""
        user = update.effective_user
        
        if user.id not in settings.ADMIN_IDS and user.id not in settings.OWNER_IDS:
            await update.message.reply_text("❌ شما دسترسی ندارید!")
            return
        
        admin_text = """
👑 *پنل مدیریت*

خوش آمدید به پنل مدیریت ربات!

📊 *مدیریت آمار*
👥 *مدیریت کاربران*
🎁 *ارسال جایزه*
📢 *ارسال پیام همگانی*
🔧 *تنظیمات ربات*
"""
        
        keyboard = [
            [
                InlineKeyboardButton("📊 آمار", callback_data="admin_stats"),
                InlineKeyboardButton("👥 کاربران", callback_data="admin_users")
            ],
            [
                InlineKeyboardButton("🎁 جایزه", callback_data="admin_reward"),
                InlineKeyboardButton("📢 پیام", callback_data="admin_broadcast")
            ],
            [
                InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await update.message.reply_text(
                admin_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
        except Exception as e:
            logger.error(f"Error in admin panel: {e}")
    
    async def admin_stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """نمایش آمار ربات"""
        user = update.effective_user
        
        if user.id not in settings.ADMIN_IDS and user.id not in settings.OWNER_IDS:
            return
        
        async with db_manager.session() as session:
            user_service = UserService(session)
            total_users = await user_service.get_total_users()
            active_24h = await user_service.get_active_users(24)
            active_7d = await user_service.get_active_users(168)
        
        stats_text = f"""
📊 *آمار ربات جنگ ستارگان*

👥 *کاربران:*
• کل: {format_number(total_users)}
• فعال (24 ساعت): {format_number(active_24h)}
• فعال (7 روز): {format_number(active_7d)}

⚙️ *وضعیت سرور:*
• ✅ فعال و آنلاین
• 📊 دیتابیس: SQLite
• 🔴 Redis: {"✅ فعال" if settings.REDIS_ENABLED else "❌ غیرفعال"}

🕐 *زمان:*
• {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
"""
        
        keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            if update.callback_query:
                await update.callback_query.edit_message_text(
                    stats_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
            else:
                await update.message.reply_text(
                    stats_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
        except Exception as e:
            logger.error(f"Error in admin stats: {e}")
    
    # ═══════════════════════════════════════════════════════════════
    # Callback Query Handler
    # ═══════════════════════════════════════════════════════════════
    
    async def callback_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """مدیریت callback query ها"""
        query = update.callback_query
        await query.answer()
        
        data = query.data
        
        # Route to appropriate handler
        handlers = {
            "main_menu": self.menu_command,
            "help": self.help_command,
            "profile": self.profile_command,
            "ranking": self.ranking_command,
            "shop": self.shop_command,
            "admin_panel": self.admin_panel,
            "admin_stats": self.admin_stats,
        }
        
        handler = handlers.get(data)
        if handler:
            await handler(update, context)
        else:
            await query.answer("⚠️ این بخش در حال توسعه است!", show_alert=True)
    
    # ═══════════════════════════════════════════════════════════════
    # Lucky Box System
    # ═══════════════════════════════════════════════════════════════
    
    async def send_lucky_box(self, context: ContextTypes.DEFAULT_TYPE):
        """ارسال جعبه شانس"""
        if not settings.MAIN_GROUP_ID:
            return
        
        try:
            box_id = f"box_{int(datetime.utcnow().timestamp())}"
            
            lucky_text = """
🎁 *جعبه شانس ظاهر شد!*

اولین نفری که دکمه زیر را بزند، جایزه را می‌برد! 🎉

⚡️ سریع باش!
"""
            
            keyboard = [[InlineKeyboardButton("🎁 باز کردن", callback_data=f"open_box_{box_id}")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await context.bot.send_message(
                chat_id=settings.MAIN_GROUP_ID,
                text=lucky_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
            
            logger.info(f"Lucky box {box_id} sent successfully")
            
        except Exception as e:
            logger.error(f"Error sending lucky box: {e}")
    
    # ═══════════════════════════════════════════════════════════════
    # Error Handler
    # ═══════════════════════════════════════════════════════════════
    
    async def error_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """مدیریت خطاها"""
        logger.error(f"❌ Update {update} caused error {context.error}")
        
        try:
            if update and update.effective_message:
                await update.effective_message.reply_text(
                    "⚠️ خطایی رخ داد! لطفاً دوباره تلاش کنید.\n\n"
                    "اگر مشکل ادامه داشت، با پشتیبانی تماس بگیرید."
                )
        except Exception as e:
            logger.error(f"Error sending error message: {e}")
    
    # ═══════════════════════════════════════════════════════════════
    # Run & Shutdown
    # ═══════════════════════════════════════════════════════════════
    
    async def run(self):
        """اجرای ربات"""
        try:
            await self.initialize()
            logger.info("🤖 Bot is running...")
            await self.app.run_polling(allowed_updates=Update.ALL_TYPES)
        except KeyboardInterrupt:
            logger.info("🛑 Bot stopped by user")
        except Exception as e:
            logger.critical(f"💥 Critical error: {e}")
            raise
        finally:
            await self.shutdown()
    
    async def shutdown(self):
        """خاموش کردن ربات"""
        logger.info("🧹 Shutting down...")
        
        # Close database
        await db_manager.close()
        logger.info("Database closed")
        
        logger.success("✅ Shutdown complete")


# ═══════════════════════════════════════════════════════════════
# Main Entry Point
# ═══════════════════════════════════════════════════════════════

async def main():
    """نقطه ورود اصلی برنامه"""
    bot = StarWarsBot()
    await bot.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("👋 Goodbye!")
    except Exception as e:
        logger.critical(f"Fatal error: {e}")
        sys.exit(1)
