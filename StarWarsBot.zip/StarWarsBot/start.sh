#!/bin/bash

# ═══════════════════════════════════════════════════════════════
# 🎮 StarWars Bot - Start Script
# اسکریپت راه‌اندازی ربات
# ═══════════════════════════════════════════════════════════════

echo "🚀 راه‌اندازی ربات جنگ ستارگان..."

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "❌ محیط مجازی یافت نشد! ابتدا install.sh را اجرا کنید."
    exit 1
fi

# Activate virtual environment
source venv/bin/activate

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "❌ فایل .env یافت نشد! لطفاً ابتدا آن را ایجاد کنید."
    exit 1
fi

# Check if bot is already running
if [ -f "bot.pid" ]; then
    PID=$(cat bot.pid)
    if ps -p $PID > /dev/null 2>&1; then
        echo "⚠️  ربات در حال اجرا است! (PID: $PID)"
        echo "برای توقف ابتدا ./stop.sh را اجرا کنید."
        exit 1
    fi
fi

# Start bot in background
echo "✅ شروع ربات..."
nohup python3 main.py > logs/bot_output.log 2>&1 &
echo $! > bot.pid

echo "✅ ربات با موفقیت راه‌اندازی شد!"
echo "📊 PID: $(cat bot.pid)"
echo "📝 لاگ‌ها: logs/bot_output.log"
echo ""
echo "برای مشاهده لاگ‌ها: tail -f logs/bot_output.log"
echo "برای توقف ربات: ./stop.sh"
