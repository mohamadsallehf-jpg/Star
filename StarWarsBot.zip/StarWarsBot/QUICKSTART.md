# 🚀 راهنمای سریع نصب روی VPS

## گام 1: اتصال به VPS

```bash
ssh root@YOUR_VPS_IP
```

## گام 2: آپدیت سیستم

```bash
apt update && apt upgrade -y
```

## گام 3: نصب Python 3.10+

```bash
# بررسی نسخه Python
python3 --version

# اگر نسخه قدیمی دارید، نصب Python 3.11
apt install software-properties-common -y
add-apt-repository ppa:deadsnakes/ppa -y
apt update
apt install python3.11 python3.11-venv python3.11-dev -y
```

## گام 4: نصب ابزارهای مورد نیاز

```bash
apt install git nano wget curl -y
```

## گام 5: دانلود پروژه

```bash
cd /root
# اگر فایل zip دارید
wget YOUR_FILE_URL -O StarWarsBot.zip
unzip StarWarsBot.zip
cd StarWarsBot

# یا از Git
git clone https://github.com/yourusername/StarWarsBot.git
cd StarWarsBot
```

## گام 6: اجرای نصب

```bash
chmod +x install.sh
./install.sh
```

## گام 7: پیکربندی

```bash
nano .env
```

**وارد کنید:**
- `BOT_TOKEN` - از [@BotFather](https://t.me/BotFather)
- `OWNER_IDS` - User ID خودتان (از [@userinfobot](https://t.me/userinfobot))
- سایر تنظیمات را به صورت دلخواه تغییر دهید

**ذخیره**: `Ctrl + X` سپس `Y` سپس `Enter`

## گام 8: راه‌اندازی

```bash
./start.sh
```

## گام 9: بررسی وضعیت

```bash
# مشاهده لاگ‌ها
tail -f logs/bot_output.log

# بررسی پروسه
ps aux | grep python
```

## گام 10: تست ربات

1. به ربات در تلگرام پیام `/start` بدهید
2. اگر پاسخ داد، همه چیز OK است! ✅

---

## نصب به عنوان سرویس (اختیاری ولی توصیه می‌شود)

### ایجاد سرویس systemd:

```bash
nano /etc/systemd/system/starwarsbot.service
```

**محتوا:**

```ini
[Unit]
Description=StarWars Telegram Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/StarWarsBot
Environment="PATH=/root/StarWarsBot/venv/bin"
ExecStart=/root/StarWarsBot/venv/bin/python /root/StarWarsBot/main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

**فعال‌سازی:**

```bash
systemctl daemon-reload
systemctl enable starwarsbot
systemctl start starwarsbot
```

**بررسی وضعیت:**

```bash
systemctl status starwarsbot
```

---

## دستورات مفید

```bash
# مشاهده لاگ‌ها
tail -f logs/starwars_bot.log

# ری‌استارت ربات
systemctl restart starwarsbot

# توقف ربات
systemctl stop starwarsbot

# مشاهده لاگ سرویس
journalctl -u starwarsbot -f

# بررسی استفاده CPU و RAM
htop
```

---

## رفع مشکلات رایج

### خطا: ModuleNotFoundError

```bash
source venv/bin/activate
pip install -r requirements.txt
```

### خطا: Permission Denied

```bash
chmod +x install.sh start.sh stop.sh
```

### ربات کار نمی‌کند

1. بررسی لاگ‌ها: `tail -f logs/starwars_bot.log`
2. بررسی توکن در `.env`
3. بررسی اتصال اینترنت VPS
4. اطمینان از باز بودن پورت‌های تلگرام

### دیتابیس خراب شد

```bash
rm starwars_bot.db
python3 main.py  # یک بار اجرا کنید تا دیتابیس بسازد
./start.sh
```

---

## امنیت

```bash
# فایروال (اختیاری)
apt install ufw -y
ufw allow 22/tcp  # SSH
ufw allow 80/tcp  # HTTP
ufw allow 443/tcp # HTTPS
ufw enable

# تغییر پورت SSH (توصیه می‌شود)
nano /etc/ssh/sshd_config
# Port را تغییر دهید
systemctl restart sshd
```

---

## پشتیبان‌گیری

```bash
# پشتیبان از دیتابیس
cp starwars_bot.db backups/backup_$(date +%Y%m%d).db

# پشتیبان از تنظیمات
cp .env backups/env_backup_$(date +%Y%m%d)
```

---

✅ **تمام! ربات شما الان در حال اجراست!**
