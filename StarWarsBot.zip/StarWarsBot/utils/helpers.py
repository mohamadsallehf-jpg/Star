"""
🎮 StarWars Bot - Helper Functions
توابع کمکی و ابزارهای عمومی
"""

import re
import random
from datetime import datetime, timedelta
from typing import Optional, Tuple, List


def format_number(number: int) -> str:
    """Format number with thousand separators (Persian style)"""
    return f"{number:,}"


def format_time_delta(seconds: int) -> str:
    """Format time delta in Persian"""
    if seconds < 60:
        return f"{seconds} ثانیه"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"{minutes} دقیقه"
    elif seconds < 86400:
        hours = seconds // 3600
        return f"{hours} ساعت"
    else:
        days = seconds // 86400
        return f"{days} روز"


def calculate_xp_for_level(level: int) -> int:
    """محاسبه XP مورد نیاز برای سطح"""
    return 1000 * level


def calculate_level_from_xp(total_xp: int) -> Tuple[int, int]:
    """
    محاسبه سطح از مجموع XP
    
    Returns:
        tuple: (level, remaining_xp)
    """
    level = 1
    xp = total_xp
    
    while xp >= calculate_xp_for_level(level):
        xp -= calculate_xp_for_level(level)
        level += 1
    
    return level, xp


def generate_progress_bar(
    current: int,
    maximum: int,
    length: int = 10,
    filled: str = "█",
    empty: str = "░"
) -> str:
    """Generate a progress bar"""
    if maximum == 0:
        return empty * length
    
    filled_length = int(length * current / maximum)
    filled_length = min(filled_length, length)
    
    bar = filled * filled_length + empty * (length - filled_length)
    percentage = int(100 * current / maximum)
    
    return f"{bar} {percentage}%"


def calculate_damage_with_defense(
    base_damage: int,
    defense_level: int,
    defense_type: str = "shield"
) -> int:
    """محاسبه آسیب با در نظر گرفتن دفاع"""
    # Base reduction per defense level
    reduction_per_level = {
        "shield": 5,
        "armor": 3,
        "dodge": 2
    }
    
    reduction = reduction_per_level.get(defense_type, 3)
    total_reduction = defense_level * reduction
    
    # Maximum 80% reduction
    total_reduction = min(total_reduction, 80)
    
    actual_damage = base_damage * (100 - total_reduction) / 100
    return max(int(actual_damage), 1)  # At least 1 damage


def random_outcome(probability: float) -> bool:
    """Generate random outcome based on probability (0.0 to 1.0)"""
    return random.random() < probability


def get_random_reward(min_amount: int, max_amount: int, vip_multiplier: float = 1.0) -> int:
    """Get random reward amount with VIP multiplier"""
    base_reward = random.randint(min_amount, max_amount)
    return int(base_reward * vip_multiplier)


def parse_user_mention(text: str) -> Optional[int]:
    """Parse user ID from mention"""
    # Try to extract user ID from mention
    match = re.search(r'tg://user\?id=(\d+)', text)
    if match:
        return int(match.group(1))
    
    # Try to extract from @username (if we have user data)
    match = re.search(r'@(\w+)', text)
    if match:
        return match.group(1)  # Return username for lookup
    
    return None


def validate_amount(text: str, max_amount: Optional[int] = None) -> Optional[int]:
    """Validate and extract amount from text"""
    try:
        amount = int(text)
        if amount <= 0:
            return None
        if max_amount and amount > max_amount:
            return None
        return amount
    except ValueError:
        return None


def create_battle_text(
    attacker_name: str,
    defender_name: str,
    damage: int,
    weapon_name: str,
    success: bool
) -> str:
    """Create battle result text"""
    if success:
        return (
            f"⚔️ *نبرد موفقیت‌آمیز!*\n\n"
            f"🎯 {attacker_name} با استفاده از {weapon_name}\n"
            f"💥 {damage:,} آسیب به {defender_name} وارد کرد!\n"
        )
    else:
        return (
            f"🛡️ *حمله ناموفق!*\n\n"
            f"❌ {attacker_name} نتوانست با {weapon_name}\n"
            f"به {defender_name} آسیب برساند!\n"
        )


def get_rank_emoji(rank: int) -> str:
    """Get emoji for rank"""
    rank_emojis = {
        1: "🥇",
        2: "🥈",
        3: "🥉",
    }
    return rank_emojis.get(rank, f"{rank}️⃣")


def get_level_title(level: int) -> str:
    """Get title based on level"""
    if level < 5:
        return "🌱 تازه‌کار"
    elif level < 10:
        return "⚔️ سرباز"
    elif level < 20:
        return "🎖️ ستوان"
    elif level < 30:
        return "🎗️ سروان"
    elif level < 40:
        return "🏅 سرگرد"
    elif level < 50:
        return "🎖️ سرهنگ"
    elif level < 75:
        return "⭐ سردار"
    elif level < 100:
        return "🌟 ژنرال"
    else:
        return "👑 افسانه"


def generate_lucky_box_id() -> str:
    """Generate unique lucky box ID"""
    return f"box_{int(datetime.utcnow().timestamp())}_{random.randint(1000, 9999)}"


def calculate_repair_cost(
    max_health: int,
    current_health: int,
    cost_per_hp: int
) -> int:
    """Calculate equipment repair cost"""
    health_to_repair = max_health - current_health
    return health_to_repair * cost_per_hp


def format_cooldown(last_use: Optional[datetime], cooldown_seconds: int) -> str:
    """Format cooldown time remaining"""
    if not last_use:
        return "✅ آماده"
    
    time_passed = (datetime.utcnow() - last_use).total_seconds()
    remaining = int(cooldown_seconds - time_passed)
    
    if remaining <= 0:
        return "✅ آماده"
    
    return f"⏳ {format_time_delta(remaining)}"


def get_vip_benefits(vip_level: int) -> dict:
    """Get VIP benefits based on level"""
    benefits = {
        0: {
            "coin_multiplier": 1.0,
            "work_multiplier": 1.0,
            "xp_multiplier": 1.0,
            "cooldown_reduction": 0,
            "special": []
        },
        1: {
            "coin_multiplier": 1.5,
            "work_multiplier": 1.5,
            "xp_multiplier": 1.5,
            "cooldown_reduction": 300,  # 5 minutes
            "special": ["🎁 هدیه روزانه بیشتر"]
        },
        2: {
            "coin_multiplier": 2.0,
            "work_multiplier": 2.0,
            "xp_multiplier": 2.0,
            "cooldown_reduction": 600,  # 10 minutes
            "special": ["🎁 هدیه روزانه بیشتر", "💎 یاقوت بیشتر"]
        },
        3: {
            "coin_multiplier": 2.5,
            "work_multiplier": 2.5,
            "xp_multiplier": 2.5,
            "cooldown_reduction": 900,  # 15 minutes
            "special": ["🎁 هدیه روزانه بیشتر", "💎 یاقوت بیشتر", "⚔️ آسیب بیشتر"]
        }
    }
    
    return benefits.get(vip_level, benefits[0])


def split_list_into_chunks(lst: List, chunk_size: int) -> List[List]:
    """Split a list into chunks of specified size"""
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]


def clean_html(text: str) -> str:
    """Remove HTML tags from text"""
    return re.sub(r'<[^>]+>', '', text)


def escape_markdown(text: str) -> str:
    """Escape markdown special characters"""
    special_chars = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!']
    for char in special_chars:
        text = text.replace(char, f'\\{char}')
    return text
