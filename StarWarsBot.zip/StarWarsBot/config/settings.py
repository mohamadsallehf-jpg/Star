"""
🎮 StarWars Bot - Advanced Configuration System
تنظیمات پیشرفته و کامل ربات جنگ ستارگان

این فایل تمام تنظیمات و پیکربندی‌های ربات را مدیریت می‌کند
"""

import os
from typing import List, Optional, Dict, Any
from pathlib import Path
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

# Load environment variables
env_path = Path(__file__).resolve().parent.parent / '.env'
load_dotenv(env_path)

# Base directory
BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    """تنظیمات اصلی ربات جنگ ستارگان"""
    
    # ═══════════════════════════════════════════════════════════════
    # 🤖 Bot Configuration
    # ═══════════════════════════════════════════════════════════════
    BOT_TOKEN: str = Field(..., description="Telegram Bot Token")
    BOT_USERNAME: str = Field(default="", description="Bot Username")
    
    # ═══════════════════════════════════════════════════════════════
    # 🔐 Security & Authentication
    # ═══════════════════════════════════════════════════════════════
    SECRET_KEY: str = Field(..., description="Secret key for encryption")
    JWT_SECRET: str = Field(..., description="JWT secret key")
    ENCRYPTION_KEY: str = Field(..., description="Encryption key")
    
    OWNER_IDS: List[int] = Field(default_factory=list)
    ADMIN_IDS: List[int] = Field(default_factory=list)
    
    @field_validator('OWNER_IDS', 'ADMIN_IDS', mode='before')
    @classmethod
    def parse_ids(cls, v):
        if isinstance(v, str):
            return [int(x.strip()) for x in v.split(',') if x.strip()]
        return v or []
    
    # ═══════════════════════════════════════════════════════════════
    # 🏠 Group & Channel Settings
    # ═══════════════════════════════════════════════════════════════
    MAIN_GROUP_ID: Optional[int] = Field(default=None, description="Main group chat ID")
    REQUIRED_CHANNEL: Optional[str] = Field(default=None, description="Required channel username")
    ADMIN_CHAT_ID: Optional[int] = Field(default=None, description="Admin notifications chat")
    
    # ═══════════════════════════════════════════════════════════════
    # 💾 Database Configuration
    # ═══════════════════════════════════════════════════════════════
    DATABASE_URL: str = Field(
        default="sqlite+aiosqlite:///./starwars_bot.db",
        description="Database connection URL"
    )
    DATABASE_ECHO: bool = Field(default=False, description="Echo SQL queries")
    DATABASE_POOL_SIZE: int = Field(default=20, description="Database pool size")
    DATABASE_MAX_OVERFLOW: int = Field(default=40, description="Max overflow connections")
    
    # ═══════════════════════════════════════════════════════════════
    # 🔴 Redis Configuration
    # ═══════════════════════════════════════════════════════════════
    REDIS_HOST: str = Field(default="localhost")
    REDIS_PORT: int = Field(default=6379)
    REDIS_PASSWORD: Optional[str] = Field(default=None)
    REDIS_DB: int = Field(default=0)
    REDIS_ENABLED: bool = Field(default=True)
    
    @property
    def REDIS_URL(self) -> str:
        """Redis connection URL"""
        if self.REDIS_PASSWORD:
            return f"redis://:{self.REDIS_PASSWORD}@{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"
        return f"redis://{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"
    
    # ═══════════════════════════════════════════════════════════════
    # 🚦 Rate Limiting
    # ═══════════════════════════════════════════════════════════════
    RATE_LIMIT_ENABLED: bool = Field(default=True)
    MAX_REQUESTS_PER_MINUTE: int = Field(default=30)
    MAX_REQUESTS_PER_HOUR: int = Field(default=500)
    MAX_REQUESTS_PER_DAY: int = Field(default=5000)
    
    SPAM_THRESHOLD: int = Field(default=10, description="Max messages in spam window")
    SPAM_WINDOW: int = Field(default=5, description="Spam detection window (seconds)")
    AUTO_BAN_ON_SPAM: bool = Field(default=True)
    
    # ═══════════════════════════════════════════════════════════════
    # 💰 Economy Settings
    # ═══════════════════════════════════════════════════════════════
    INITIAL_BALANCE: int = Field(default=5000, description="Starting balance in Toman")
    INITIAL_HEALTH: int = Field(default=100, description="Starting health")
    INITIAL_LEVEL: int = Field(default=1)
    INITIAL_XP: int = Field(default=0)
    
    RUBY_TO_TOMAN_RATE: int = Field(default=350, description="Ruby to Toman conversion rate")
    
    # Cooldowns (in seconds)
    WORK_COOLDOWN: int = Field(default=1800, description="30 minutes")
    COIN_COOLDOWN: int = Field(default=3600, description="1 hour")
    DAILY_COOLDOWN: int = Field(default=86400, description="24 hours")
    MINE_RUBY_COOLDOWN: int = Field(default=3600, description="1 hour")
    
    # Rewards
    WORK_MIN_REWARD: int = Field(default=500)
    WORK_MAX_REWARD: int = Field(default=2000)
    COIN_MIN_REWARD: int = Field(default=300)
    COIN_MAX_REWARD: int = Field(default=1000)
    DAILY_REWARD: int = Field(default=5000)
    
    # ═══════════════════════════════════════════════════════════════
    # 🎮 Game Features
    # ═══════════════════════════════════════════════════════════════
    ENABLE_PVP: bool = Field(default=True)
    ENABLE_MISSIONS: bool = Field(default=True)
    ENABLE_ACHIEVEMENTS: bool = Field(default=True)
    ENABLE_LUCKY_BOX: bool = Field(default=True)
    ENABLE_DAILY_BONUS: bool = Field(default=True)
    
    # Lucky Box Settings
    LUCKY_BOX_INTERVAL: int = Field(default=300, description="5 minutes in seconds")
    LUCKY_BOX_MIN_REWARD: int = Field(default=100)
    LUCKY_BOX_MAX_REWARD: int = Field(default=5000)
    
    # ═══════════════════════════════════════════════════════════════
    # 📊 Logging Configuration
    # ═══════════════════════════════════════════════════════════════
    LOG_LEVEL: str = Field(default="INFO")
    LOG_FILE: str = Field(default="logs/starwars_bot.log")
    LOG_ROTATION: str = Field(default="10 MB")
    LOG_RETENTION: str = Field(default="30 days")
    LOG_FORMAT: str = Field(
        default="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan> - <level>{message}</level>"
    )
    
    # ═══════════════════════════════════════════════════════════════
    # 🎯 Game Data Paths
    # ═══════════════════════════════════════════════════════════════
    @property
    def ASSETS_DIR(self) -> Path:
        return BASE_DIR / "assets"
    
    @property
    def DATA_DIR(self) -> Path:
        return BASE_DIR / "data"
    
    @property
    def LOGS_DIR(self) -> Path:
        return BASE_DIR / "logs"
    
    @property
    def BACKUPS_DIR(self) -> Path:
        return BASE_DIR / "backups"
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


# ═══════════════════════════════════════════════════════════════
# 🎮 Game Configuration Data
# ═══════════════════════════════════════════════════════════════

class GameConfig:
    """تنظیمات بازی - سلاح‌ها، تجهیزات و موارد دیگر"""
    
    # ═══════════════════════════════════════════════════════════════
    # 🚀 Missiles (موشک‌ها)
    # ═══════════════════════════════════════════════════════════════
    MISSILES: Dict[str, Dict[str, Any]] = {
        "فاتح": {
            "name": "🪖 فاتح",
            "damage": 85,
            "cost": 450,
            "cooldown": 3000,
            "required_level": 1,
            "emoji": "🪖",
            "type": "بالستیک"
        },
        "عماد": {
            "name": "⚡ عماد",
            "damage": 70,
            "cost": 350,
            "cooldown": 2000,
            "required_level": 1,
            "emoji": "⚡",
            "type": "بالستیک"
        },
        "سجیل": {
            "name": "🔥 سجیل",
            "damage": 95,
            "cost": 550,
            "cooldown": 4000,
            "required_level": 2,
            "emoji": "🔥",
            "type": "بالستیک"
        },
        "خیبرشکن": {
            "name": "💥 خیبرشکن",
            "damage": 110,
            "cost": 700,
            "cooldown": 5000,
            "required_level": 2,
            "emoji": "💥",
            "type": "بالستیک"
        },
        "شهاب": {
            "name": "☄️ شهاب",
            "damage": 120,
            "cost": 900,
            "cooldown": 5500,
            "required_level": 3,
            "emoji": "☄️",
            "type": "بالستیک"
        },
        "قدر": {
            "name": "🌟 قدر",
            "damage": 150,
            "cost": 1100,
            "cooldown": 6500,
            "required_level": 5,
            "emoji": "🌟",
            "type": "بالستیک"
        },
        "هسته‌ای": {
            "name": "☢️ هسته‌ای",
            "damage": 300,
            "cost": 2200,
            "cooldown": 12000,
            "required_level": 8,
            "emoji": "☢️",
            "type": "استراتژیک",
            "special": "آسیب به کل منطقه"
        }
    }
    
    # ═══════════════════════════════════════════════════════════════
    # 🛡️ Defense Systems (سیستم‌های دفاعی)
    # ═══════════════════════════════════════════════════════════════
    DEFENSE_SYSTEMS: Dict[str, Dict[str, Any]] = {
        "پدافند": {
            "name": "🛡️ پدافند",
            "protection": 30,
            "cost": 500,
            "max_level": 5,
            "emoji": "🛡️",
            "upgrade_cost": 250,
            "salary": 50
        },
        "رادار": {
            "name": "📡 رادار",
            "detection": 0.4,
            "cost": 350,
            "max_level": 4,
            "emoji": "📡",
            "upgrade_cost": 180,
            "salary": 40
        },
        "سامانه": {
            "name": "🚀 سامانه",
            "intercept": 0.5,
            "cost": 700,
            "max_level": 4,
            "emoji": "🚀",
            "upgrade_cost": 350,
            "salary": 70
        },
        "گنبد": {
            "name": "🕌 گنبد آهنین",
            "protection": 50,
            "cost": 1000,
            "max_level": 5,
            "emoji": "🕌",
            "upgrade_cost": 500,
            "salary": 100
        }
    }
    
    # ═══════════════════════════════════════════════════════════════
    # 🪖 Tanks (تانک‌ها)
    # ═══════════════════════════════════════════════════════════════
    TANKS: Dict[str, Dict[str, Any]] = {
        "تی-72": {
            "name": "🇷🇺 تی-72",
            "damage": 60,
            "cost": 700,
            "cooldown": 1500,
            "required_level": 2,
            "emoji": "🇷🇺",
            "type": "متوسط",
            "max_health": 100,
            "repair_cost_per_hp": 5
        },
        "آبرامز": {
            "name": "🇺🇸 آبرامز",
            "damage": 80,
            "cost": 1100,
            "cooldown": 2000,
            "required_level": 4,
            "emoji": "🇺🇸",
            "type": "سنگین",
            "max_health": 120,
            "repair_cost_per_hp": 6
        },
        "ذوالفقار": {
            "name": "🇮🇷 ذوالفقار",
            "damage": 85,
            "cost": 1200,
            "cooldown": 2200,
            "required_level": 5,
            "emoji": "🇮🇷",
            "type": "سنگین",
            "max_health": 130,
            "repair_cost_per_hp": 7
        }
    }
    
    # ═══════════════════════════════════════════════════════════════
    # ✈️ Fighters (جنگنده‌ها)
    # ═══════════════════════════════════════════════════════════════
    FIGHTERS: Dict[str, Dict[str, Any]] = {
        "اف-16": {
            "name": "🇺🇸 اف-16",
            "damage": 70,
            "cost": 900,
            "cooldown": 2000,
            "required_level": 3,
            "emoji": "🇺🇸",
            "type": "چندمنظوره",
            "max_health": 80,
            "repair_cost_per_hp": 7
        },
        "سوخو-35": {
            "name": "🇷🇺 سوخو-35",
            "damage": 85,
            "cost": 1300,
            "cooldown": 3000,
            "required_level": 5,
            "emoji": "🇷🇺",
            "type": "برتری هوایی",
            "max_health": 90,
            "repair_cost_per_hp": 8
        },
        "کوثر": {
            "name": "🇮🇷 کوثر",
            "damage": 75,
            "cost": 1000,
            "cooldown": 2200,
            "required_level": 4,
            "emoji": "🇮🇷",
            "type": "جنگنده سبک",
            "max_health": 85,
            "repair_cost_per_hp": 7
        }
    }
    
    # ═══════════════════════════════════════════════════════════════
    # 🚢 Warships (کشتی‌های جنگی)
    # ═══════════════════════════════════════════════════════════════
    WARSHIPS: Dict[str, Dict[str, Any]] = {
        "ناوچه": {
            "name": "🚢 ناوچه",
            "damage": 90,
            "cost": 1600,
            "cooldown": 4000,
            "required_level": 6,
            "emoji": "🚢",
            "type": "سطحی",
            "max_health": 150,
            "repair_cost_per_hp": 4
        },
        "ناوشکن": {
            "name": "⚓ ناوشکن",
            "damage": 110,
            "cost": 2200,
            "cooldown": 5000,
            "required_level": 8,
            "emoji": "⚓",
            "type": "سطحی",
            "max_health": 180,
            "repair_cost_per_hp": 5
        },
        "زیردریایی": {
            "name": "🚤 زیردریایی",
            "damage": 130,
            "cost": 2700,
            "cooldown": 6000,
            "required_level": 10,
            "emoji": "🚤",
            "type": "پنهان‌کار",
            "max_health": 130,
            "repair_cost_per_hp": 6
        }
    }
    
    # ═══════════════════════════════════════════════════════════════
    # 🎯 Drones (پهپادها)
    # ═══════════════════════════════════════════════════════════════
    DRONES: Dict[str, Dict[str, Any]] = {
        "شاهد-136": {
            "name": "💥 شاهد-136",
            "damage": 70,
            "cost": 800,
            "cooldown": 2000,
            "required_level": 3,
            "emoji": "💥",
            "type": "انتحاری",
            "max_health": 60,
            "repair_cost_per_hp": 8
        },
        "آرش": {
            "name": "🚀 آرش",
            "damage": 85,
            "cost": 1100,
            "cooldown": 2500,
            "required_level": 4,
            "emoji": "🚀",
            "type": "انتحاری",
            "max_health": 70,
            "repair_cost_per_hp": 9
        }
    }
    
    # ═══════════════════════════════════════════════════════════════
    # 💻 Cyber Attacks (حملات سایبری)
    # ═══════════════════════════════════════════════════════════════
    CYBER_ATTACKS: Dict[str, Dict[str, Any]] = {
        "هک اطلاعات": {
            "name": "🕵️‍♂️ هک اطلاعات",
            "cost": 1000,
            "cooldown": 7200,
            "required_level": 5,
            "emoji": "🕵️‍♂️",
            "type": "اطلاعاتی",
            "effect": "disrupt_defense",
            "salary": 100
        },
        "هک مالی": {
            "name": "💸 هک مالی",
            "cost": 1500,
            "cooldown": 10800,
            "required_level": 7,
            "emoji": "💸",
            "type": "مالی",
            "effect": "steal_toman",
            "salary": 150
        }
    }
    
    # ═══════════════════════════════════════════════════════════════
    # 🏆 Achievements (دستاوردها)
    # ═══════════════════════════════════════════════════════════════
    ACHIEVEMENTS: Dict[str, Dict[str, Any]] = {
        "first_blood": {
            "name": "🩸 اولین خون",
            "description": "اولین حمله موفق خود را انجام دهید",
            "reward_toman": 1000,
            "reward_ruby": 10,
            "emoji": "🩸"
        },
        "warrior": {
            "name": "⚔️ جنگجو",
            "description": "10 حمله موفق انجام دهید",
            "requirement": 10,
            "reward_toman": 5000,
            "reward_ruby": 50,
            "emoji": "⚔️"
        },
        "legendary": {
            "name": "🌟 افسانه‌ای",
            "description": "به سطح 10 برسید",
            "requirement": 10,
            "reward_toman": 10000,
            "reward_ruby": 100,
            "emoji": "🌟"
        },
        "rich": {
            "name": "💰 ثروتمند",
            "description": "100,000 تومان داشته باشید",
            "requirement": 100000,
            "reward_toman": 20000,
            "reward_ruby": 200,
            "emoji": "💰"
        }
    }
    
    # ═══════════════════════════════════════════════════════════════
    # 🎯 Daily Missions (ماموریت‌های روزانه)
    # ═══════════════════════════════════════════════════════════════
    DAILY_MISSIONS: Dict[str, Dict[str, Any]] = {
        "attack_3": {
            "name": "⚔️ مهاجم",
            "description": "3 حمله موفق انجام دهید",
            "requirement": 3,
            "reward_toman": 2000,
            "reward_xp": 500,
            "emoji": "⚔️"
        },
        "earn_5000": {
            "name": "💰 سرمایه‌دار",
            "description": "5000 تومان کسب کنید",
            "requirement": 5000,
            "reward_toman": 3000,
            "reward_xp": 700,
            "emoji": "💰"
        },
        "upgrade_1": {
            "name": "⬆️ ارتقا دهنده",
            "description": "یک تجهیزات را ارتقا دهید",
            "requirement": 1,
            "reward_toman": 1500,
            "reward_xp": 400,
            "emoji": "⬆️"
        }
    }


# Create global settings instance
settings = Settings()
game_config = GameConfig()
