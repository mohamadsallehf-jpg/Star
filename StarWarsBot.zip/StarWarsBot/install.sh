#!/bin/bash

# ═══════════════════════════════════════════════════════════════
# 🎮 StarWars Bot - Installation Script
# اسکریپت نصب و راه‌اندازی ربات جنگ ستارگان
# ═══════════════════════════════════════════════════════════════

echo "🚀 نصب ربات جنگ ستارگان..."
echo "═══════════════════════════════════════════════════════════════"

# Check if Python 3.10+ is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 یافت نشد! لطفاً ابتدا Python نصب کنید."
    exit 1
fi

PYTHON_VERSION=$(python3 --version | grep -oP '3\.\d+')
echo "✅ Python $PYTHON_VERSION یافت شد"

# Create virtual environment
echo ""
echo "📦 ایجاد محیط مجازی..."
python3 -m venv venv

# Activate virtual environment
echo "✅ فعال‌سازی محیط مجازی..."
source venv/bin/activate

# Upgrade pip
echo ""
echo "⬆️ بروزرسانی pip..."
pip install --upgrade pip

# Install dependencies
echo ""
echo "📚 نصب کتابخانه‌ها..."
pip install -r requirements.txt

# Create .env file if not exists
if [ ! -f .env ]; then
    echo ""
    echo "📝 ایجاد فایل .env..."
    cp .env.example .env
    echo "⚠️  لطفاً فایل .env را ویرایش کنید و اطلاعات مورد نیاز را وارد کنید!"
else
    echo "✅ فایل .env موجود است"
fi

# Create necessary directories
echo ""
echo "📁 ایجاد پوشه‌های مورد نیاز..."
mkdir -p logs data backups assets

# Make scripts executable
echo ""
echo "🔧 تنظیم مجوز اسکریپت‌ها..."
chmod +x start.sh
chmod +x stop.sh

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "✅ نصب با موفقیت انجام شد!"
echo ""
echo "📝 مراحل بعدی:"
echo "1. فایل .env را ویرایش کنید و BOT_TOKEN خود را وارد کنید"
echo "2. سایر تنظیمات را در .env پیکربندی کنید"
echo "3. برای اجرای ربات: ./start.sh"
echo "4. برای توقف ربات: ./stop.sh"
echo ""
echo "📚 برای راهنمای کامل README.md را مطالعه کنید"
echo "═══════════════════════════════════════════════════════════════"
