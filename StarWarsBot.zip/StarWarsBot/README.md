# 🎮 ربات جنگ ستارگان (StarWars Bot)

<div dir="rtl">

یک ربات تلگرام قدرتمند و حرفه‌ای برای بازی جنگی با امکانات پیشرفته

## ✨ ویژگی‌ها

### 💰 سیستم اقتصادی پیشرفته
- کسب درآمد از طریق کار کردن
- دریافت سکه رایگان
- جایزه روزانه
- استخراج یاقوت
- سیستم بانکی
- تبدیل یاقوت به تومان

### ⚔️ سیستم نبرد و تجهیزات
- **موشک‌ها**: فاتح، عماد، سجیل، خیبرشکن، شهاب، قدر، هسته‌ای و...
- **تانک‌ها**: تی-72، آبرامز، چلنجر، ذوالفقار، سبلان
- **جنگنده‌ها**: اف-16، سوخو-35، میراژ-2000، کوثر، صاعقه
- **کشتی‌های جنگی**: ناوچه، ناوشکن، زیردریایی، جماران
- **پهپادها**: شاهد-136، آرش، کمان-12
- **حملات سایبری**: هک اطلاعات، هک مالی

### 🛡️ سیستم دفاعی
- پدافند هوایی
- رادار
- سامانه موشکی
- گنبد آهنین
- فایروال و آنتی‌ویروس

### 🎯 سیستم‌های پیشرفته
- ماموریت‌های روزانه
- دستاوردها
- سیستم سطح و تجربه
- رتبه‌بندی و لیدربورد
- جعبه شانس
- سیستم VIP چند سطحی

### 👑 پنل ادمین
- مشاهده آمار کامل
- مدیریت کاربران
- ارسال پیام همگانی
- ارسال جایزه به کاربران
- ایجاد کد هدیه

## 📋 پیش‌نیازها

- Python 3.10 یا بالاتر
- Ubuntu 24 (یا سایر توزیع‌های لینوکس)
- دسترسی root به VPS
- توکن ربات تلگرام از [@BotFather](https://t.me/BotFather)

## 🚀 نصب و راه‌اندازی

### 1️⃣ دانلود پروژه

```bash
# اگر از Git استفاده می‌کنید
git clone https://github.com/yourusername/StarWarsBot.git
cd StarWarsBot

# یا فایل zip را استخراج کنید
unzip StarWarsBot.zip
cd StarWarsBot
```

### 2️⃣ اجرای اسکریپت نصب

```bash
chmod +x install.sh
./install.sh
```

این اسکریپت موارد زیر را انجام می‌دهد:
- ✅ بررسی نسخه Python
- ✅ ایجاد محیط مجازی
- ✅ نصب تمام کتابخانه‌های مورد نیاز
- ✅ ایجاد فایل `.env`
- ✅ ایجاد پوشه‌های لازم

### 3️⃣ پیکربندی

فایل `.env` را ویرایش کنید:

```bash
nano .env
```

**مهم‌ترین تنظیمات:**

```env
# توکن ربات از BotFather
BOT_TOKEN=YOUR_BOT_TOKEN_HERE

# آی‌دی مالک (Owner)
OWNER_IDS=123456789

# آی‌دی ادمین‌ها (جدا شده با کاما)
ADMIN_IDS=111111111,222222222

# آی‌دی گروه اصلی (اختیاری)
MAIN_GROUP_ID=-1001234567890

# کانال الزامی (اختیاری)
REQUIRED_CHANNEL=@YourChannel
```

**نکات مهم:**
- برای دریافت User ID می‌توانید از [@userinfobot](https://t.me/userinfobot) استفاده کنید
- برای دریافت Group ID، ربات را به گروه اضافه کرده و پیامی ارسال کنید
- Channel ID همیشا با @ شروع می‌شود

### 4️⃣ راه‌اندازی ربات

```bash
./start.sh
```

### 5️⃣ مشاهده لاگ‌ها

```bash
tail -f logs/bot_output.log
# یا
tail -f logs/starwars_bot.log
```

### 6️⃣ توقف ربات

```bash
./stop.sh
```

### 7️⃣ ری‌استارت ربات

```bash
./stop.sh && ./start.sh
```

## 🔧 راه‌اندازی با systemd (اجرای دائمی)

برای اینکه ربات به صورت دائمی و حتی بعد از ری‌استارت سرور اجرا شود:

### 1️⃣ ایجاد سرویس

```bash
sudo nano /etc/systemd/system/starwarsbot.service
```

محتوای فایل:

```ini
[Unit]
Description=StarWars Telegram Bot
After=network.target

[Service]
Type=simple
User=YOUR_USERNAME
WorkingDirectory=/path/to/StarWarsBot
Environment="PATH=/path/to/StarWarsBot/venv/bin"
ExecStart=/path/to/StarWarsBot/venv/bin/python /path/to/StarWarsBot/main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

**نکته**: `YOUR_USERNAME` و مسیرها را با مقادیر واقعی جایگزین کنید.

### 2️⃣ فعال‌سازی سرویس

```bash
sudo systemctl daemon-reload
sudo systemctl enable starwarsbot
sudo systemctl start starwarsbot
```

### 3️⃣ مدیریت سرویس

```bash
# مشاهده وضعیت
sudo systemctl status starwarsbot

# توقف
sudo systemctl stop starwarsbot

# ری‌استارت
sudo systemctl restart starwarsbot

# مشاهده لاگ‌ها
sudo journalctl -u starwarsbot -f
```

## 📱 نحوه استفاده

### برای کاربران عادی:

1. **شروع**: دستور `/start` را به ربات ارسال کنید
2. **پروفایل**: مشاهده اطلاعات خود با `/profile`
3. **کسب درآمد**: 
   - `/coin` - دریافت سکه رایگان (هر 1 ساعت)
   - `/work` - کار کردن (هر 30 دقیقه)
   - `/daily` - جایزه روزانه (هر 24 ساعت)
   - `/mine` - استخراج یاقوت (هر 1 ساعت)
4. **خرید تجهیزات**: از `/shop` استفاده کنید
5. **حمله**: با `/attack` به دشمنان حمله کنید
6. **رتبه‌بندی**: با `/ranking` بهترین‌ها را ببینید

### برای ادمین‌ها:

1. **پنل ادمین**: `/admin`
2. **آمار**: `/stats`
3. **مدیریت کاربران**: از پنل ادمین
4. **ارسال پیام همگانی**: از پنل ادمین

## 🗂️ ساختار پروژه

```
StarWarsBot/
├── main.py                 # فایل اصلی
├── requirements.txt        # کتابخانه‌ها
├── .env.example           # نمونه تنظیمات
├── .env                   # تنظیمات (ایجاد می‌شود)
│
├── config/                # تنظیمات
│   ├── __init__.py
│   └── settings.py        # تمام تنظیمات
│
├── models/                # مدل‌های دیتابیس
│   ├── __init__.py
│   ├── base.py           # پایه دیتابیس
│   └── user.py           # مدل کاربر
│
├── services/              # سرویس‌ها
│   ├── __init__.py
│   └── user_service.py   # سرویس کاربر
│
├── utils/                 # ابزارها
│   ├── __init__.py
│   └── helpers.py        # توابع کمکی
│
├── handlers/              # هندلرها (در صورت نیاز)
├── middlewares/           # میدلورها (در صورت نیاز)
│
├── logs/                  # لاگ‌ها
├── data/                  # دیتاها
├── backups/               # پشتیبان‌ها
├── assets/                # تصاویر و فایل‌ها
│
└── scripts/               # اسکریپت‌های کمکی
    ├── install.sh         # نصب
    ├── start.sh          # راه‌اندازی
    └── stop.sh           # توقف
```

## 🐛 رفع مشکلات

### ربات اجرا نمی‌شود

```bash
# بررسی لاگ‌ها
tail -f logs/bot_output.log
tail -f logs/starwars_bot.log

# بررسی پروسه
ps aux | grep python
```

### خطای Python یا کتابخانه

```bash
# حذف محیط مجازی و نصب مجدد
rm -rf venv
./install.sh
```

### خطای دیتابیس

```bash
# حذف دیتابیس و ایجاد مجدد
rm starwars_bot.db
python3 main.py
```

### خطای Permission Denied

```bash
# دادن مجوز اجرا
chmod +x install.sh start.sh stop.sh
```

## 🔒 امنیت

- ⚠️ **هرگز** فایل `.env` را در Git قرار ندهید
- 🔐 توکن ربات و کلیدهای امنیتی را محرمانه نگه دارید
- 🛡️ فقط به افراد مورد اعتماد دسترسی ادمین بدهید
- 📝 به طور منظم از دیتابیس backup بگیرید

## 🔄 بروزرسانی

```bash
# دانلود نسخه جدید
git pull origin main

# نصب کتابخانه‌های جدید (در صورت وجود)
source venv/bin/activate
pip install -r requirements.txt --upgrade

# ری‌استارت ربات
./stop.sh && ./start.sh
```

## 🤝 مشارکت

برای مشارکت در توسعه پروژه:

1. Fork کنید
2. یک branch جدید بسازید
3. تغییرات خود را commit کنید
4. Push به branch خود
5. Pull Request ایجاد کنید

## 📄 لایسنس

این پروژه تحت لایسنس MIT منتشر شده است.

## 💬 پشتیبانی

- 🐛 گزارش باگ: از طریق Issues در GitHub
- 💡 پیشنهاد: از طریق Discussions در GitHub
- 📧 ایمیل: support@example.com
- 💬 تلگرام: @YourSupportChannel

## 📊 آمار پروژه

- ✅ تست شده روی Ubuntu 24
- ✅ Python 3.10+
- ✅ بدون باگ شناخته شده
- ✅ مستندات کامل فارسی
- ✅ پشتیبانی و بروزرسانی فعال

## 🎯 نقشه راه

- [ ] سیستم گیلد و تیم‌ها
- [ ] نبردهای گروهی
- [ ] رویدادهای ویژه
- [ ] سیستم فصل‌ها
- [ ] API عمومی

---

**ساخته شده با ❤️ برای جامعه ایرانی**

</div>
